clang -L. -lfoo -m32 -otestfoo testfoo.c
clang -L. -lfoo -m64 -otestfoo64 testfoo.c
lipo -create testfoo testfoo64 -output testfoo
rm testfoo64
