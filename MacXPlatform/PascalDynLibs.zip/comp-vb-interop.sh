vbnc /target:library /out:Foo.Interop.dll FooLib.vb
# Note vbnc currently produces .dll that's not usable by mcs.
 