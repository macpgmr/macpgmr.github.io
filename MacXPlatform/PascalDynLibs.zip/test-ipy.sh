mono ~/Tools/IronPython-2.7.5/ipy.exe testfoo.py
