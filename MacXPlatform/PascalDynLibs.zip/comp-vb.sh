vbnc /target:exe /reference:Foo.Interop.dll testfoo.vb 
