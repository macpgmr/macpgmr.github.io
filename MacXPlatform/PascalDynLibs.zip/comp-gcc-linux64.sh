gcc -otestfoo testfoo.c -L. -lfoo64
