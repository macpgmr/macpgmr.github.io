mcs /target:exe /platform:x86 /reference:Foo.Interop.dll testfoo.cs
