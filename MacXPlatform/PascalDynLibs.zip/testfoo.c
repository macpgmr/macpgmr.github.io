// testfoo.c
#include "foo.h"
#include <stdio.h>

int main()
{
  printf("%d\n", FooGetVal(1));
}
