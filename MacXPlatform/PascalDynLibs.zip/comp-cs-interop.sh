mcs /target:library /platform:x86 /out:Foo.Interop.dll FooLib.cs
