xcrun swiftc -import-objc-header foo.h -L. -lfoo testfoo.swift
