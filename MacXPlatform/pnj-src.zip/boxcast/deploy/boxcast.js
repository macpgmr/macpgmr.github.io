rtl.module("System", [], function () {
  var $mod = this;
  rtl.createClass($mod, "TObject", null, function () {
    this.$init = function () {
    };
    this.$final = function () {
    };
  });
  this.ExitCode = 0;
});

rtl.module("JS_Intf", ["System"], function () {
  var $mod = this;
});

rtl.module("DOM_Intf", ["System"], function () {
  var $mod = this;
});

rtl.module("HTML_Intf", ["System", "DOM_Intf"], function () {
  var $mod = this;
});

rtl.module("Corslite_Intf", ["System"], function () {
  var $mod = this;
});

rtl.module("MapboxGL_Intf", ["System", "DOM_Intf", "HTML_Intf"], function () {
  var $mod = this;
  rtl.createClass($mod, "TMapOptions", pas.System.TObject, function () {
    this.$init = function () {
      pas.System.TObject.$init.call(this);
      this.container = "";
      this.minZoom = 0.0;
      this.maxZoom = 0.0;
      this.style = "";
      this.hash = false;
      this.interactive = false;
      this.bearingSnap = 0.0;
      this.pitchWithRotate = false;
      this.attributionControl = false;
      this.logoPosition = "";
      this.failIfMajorPerformanceCaveat = false;
      this.preserveDrawingBuffer = false;
      this.refreshExpiredTiles = false;
      this.maxBounds = null;
      this.scrollZoom = false;
      this.boxZoom = false;
      this.dragRotate = false;
      this.dragPan = false;
      this.keyboard = false;
      this.doubleClickZoom = false;
      this.touchZoomRotate = false;
      this.trackResize = false;
      this.center = null;
      this.zoom = 0.0;
      this.bearing = 0.0;
      this.pitch = 0.0;
      this.renderWorldCopies = false;
      this.maxTileCacheSize = 0.0;
      this.localIdeographFontFamily = "";
    };
    this.$final = function () {
      this.maxBounds = undefined;
      this.center = undefined;
      pas.System.TObject.$final.call(this);
    };
    this.Create = function () {
      this.minZoom = mapboxgl.defaultMinZoom;
      this.maxZoom = mapboxgl.defaultMaxZoom;
      this.hash = false;
      this.interactive = true;
      this.bearingSnap = 7;
      this.pitchWithRotate = true;
      this.attributionControl = true;
      this.logoPosition = "bottom-left";
      this.failIfMajorPerformanceCaveat = false;
      this.preserveDrawingBuffer = false;
      this.refreshExpiredTiles = true;
      this.scrollZoom = true;
      this.boxZoom = true;
      this.dragRotate = true;
      this.dragPan = true;
      this.keyboard = true;
      this.doubleClickZoom = true;
      this.touchZoomRotate = true;
      this.trackResize = true;
      this.center = new mapboxgl.LngLat(0, 0);
      this.zoom = 0;
      this.bearing = 0;
      this.pitch = 0;
      this.renderWorldCopies = true;
      this.maxTileCacheSize = 0;
      this.localIdeographFontFamily = "";
    };
  });
  rtl.createClass($mod, "TStyleOptions", pas.System.TObject, function () {
    this.$init = function () {
      pas.System.TObject.$init.call(this);
      this.diff = false;
      this.localIdeographFontFamily = "";
    };
    this.Create = function () {
      this.diff = true;
      this.localIdeographFontFamily = "";
    };
  });
  rtl.createClass($mod, "TPopupOptions", pas.System.TObject, function () {
    this.$init = function () {
      pas.System.TObject.$init.call(this);
      this.closeButton = false;
      this.closeOnClick = false;
      this.anchor = "";
      this.offset = 0.0;
    };
    this.Create = function () {
      this.closeButton = true;
      this.closeOnClick = true;
      this.anchor = "bottom";
      this.offset = 0;
    };
  });
  rtl.createClass($mod, "TMarkerOptions", pas.System.TObject, function () {
    this.$init = function () {
      pas.System.TObject.$init.call(this);
      this.offset = null;
    };
    this.$final = function () {
      this.offset = undefined;
      pas.System.TObject.$final.call(this);
    };
  });
  rtl.createClass($mod, "TScaleOptions", pas.System.TObject, function () {
    this.$init = function () {
      pas.System.TObject.$init.call(this);
      this.maxWidth = 0.0;
      this.unit = "";
    };
    this.Create = function () {
      this.maxWidth = 150;
      this.unit = "metric";
    };
  });
  rtl.createClass($mod, "TSupportedOptions", pas.System.TObject, function () {
    this.$init = function () {
      pas.System.TObject.$init.call(this);
      this.failIfMajorPerformanceCaveat = false;
    };
  });
  rtl.createClass($mod, "TAnimationOptions", pas.System.TObject, function () {
    this.$init = function () {
      pas.System.TObject.$init.call(this);
      this.duration = 0.0;
      this.easing = null;
      this.offset = null;
      this.animate = false;
    };
    this.$final = function () {
      this.easing = undefined;
      this.offset = undefined;
      pas.System.TObject.$final.call(this);
    };
  });
  rtl.createClass($mod, "TCameraOptions", pas.System.TObject, function () {
    this.$init = function () {
      pas.System.TObject.$init.call(this);
      this.center = null;
      this.zoom = 0.0;
      this.bearing = 0.0;
      this.pitch = 0.0;
      this.around = null;
    };
    this.$final = function () {
      this.center = undefined;
      this.around = undefined;
      pas.System.TObject.$final.call(this);
    };
  });
});

rtl.module("BoxCast_Config", ["System"], function () {
  var $mod = this;
  rtl.createClass($mod, "TAppSettings", pas.System.TObject, function () {
    this.$init = function () {
      pas.System.TObject.$init.call(this);
      this.name = "";
      this.version = "";
      this.copyright = "";
      this.fcstUrl = "";
      this.accessToken = "";
    };
    this.Create = function () {
      this.name = "BoxCast";
      this.version = "0.1";
      this.copyright = "Copyright 2017 Phil Hess";
      this.fcstUrl = "http:\/\/localhost\/cgi-bin\/getforecast.cgi";
      this.accessToken = "your-access-token-goes-here";
    };
  });
  this.appSettings = null;
  $mod.$init = function () {
    $mod.appSettings = $mod.TAppSettings.$create("Create");
  };
});

rtl.module("program", [
  "System",
  "JS_Intf",
  "DOM_Intf",
  "HTML_Intf",
  "Corslite_Intf",
  "MapboxGL_Intf",
  "BoxCast_Config"
], function () {
  var $mod = this;
  rtl.createClass($mod, "TAboutButtonControl", pas.System.TObject, function () {
    this.$init = function () {
      pas.System.TObject.$init.call(this);
      this._map = null;
      this._container = null;
    };
    this.$final = function () {
      this._map = undefined;
      this._container = undefined;
      pas.System.TObject.$final.call(this);
    };
    this.New = function () {
    };
    this.onAdd = function (map) {
      var Result = null;
      this._map = map;
      this._container = document.createElement("button");
      this._container.className = "mapboxgl-ctrl";
      this._container.innerHTML = "<b>About<\/b>";
      Result = this._container;
      return Result;
    };
    this.onRemove = function (map) {
      this._container.parentNode.removeChild(this._container);
      this._map = undefined;
    };
  });
  rtl.createClass($mod, "TFcstGeometry", pas.System.TObject, function () {
    this.$init = function () {
      pas.System.TObject.$init.call(this);
      this.type = "";
      this.coordinates = [];
    };
    this.$final = function () {
      this.coordinates = undefined;
      pas.System.TObject.$final.call(this);
    };
  });
  rtl.createClass($mod, "TFcstProperties", pas.System.TObject, function () {
    this.$init = function () {
      pas.System.TObject.$init.call(this);
      this.high = "";
      this.low = "";
    };
  });
  rtl.createClass($mod, "TFcstFeature", pas.System.TObject, function () {
    this.$init = function () {
      pas.System.TObject.$init.call(this);
      this.type = "";
      this.geometry = null;
      this.properties = null;
    };
    this.$final = function () {
      this.geometry = undefined;
      this.properties = undefined;
      pas.System.TObject.$final.call(this);
    };
  });
  rtl.createClass($mod, "TFcstGeoJSON", pas.System.TObject, function () {
    this.$init = function () {
      pas.System.TObject.$init.call(this);
      this.type = "";
      this.features = [];
    };
    this.$final = function () {
      this.features = undefined;
      pas.System.TObject.$final.call(this);
    };
  });
  this.map = null;
  this.AboutOnClick = function (e) {
    var popup = null;
    var popupOptions = null;
    popupOptions = pas.MapboxGL_Intf.TPopupOptions.$create("Create");
    popup = new mapboxgl.Popup(popupOptions);
    popup.setLngLat($mod.map.getCenter());
    popup.setHTML(((((((((("<center><h3>" + pas.BoxCast_Config.appSettings.name) + ", version ") + pas.BoxCast_Config.appSettings.version) + "<\/h3>") + '<h4>Powered by <a href="https:\/\/mapbox.com" target="_blank">Mapbox GL JS<\/a>, version ') + mapboxgl.version) + "<br>") + 'Weather forecasts from <a href="http:\/\/www.usgovxml.com\/DataService.aspx?ds=NDFD" ') + 'target="_blank">National Digital Forecast Database<\/a><\/h4>') + "Click anywhere in the U.S. to see today's weather forecast.<\/center>");
    popup.addTo($mod.map);
  };
  this.MapOnClick = function (e) {
    function CorsCallback(err, resp) {
      var popupText = "";
      var fcst = null;
      if (err !== null) {
        popupText = "Error retrieving forecast.";
        console.log(popupText);
      } else {
        try {
          fcst = JSON.parse(resp.response);
          popupText = ((((("<center>Today's forecast<br>" + "High: <b>") + fcst.features[0].properties.high) + "<\/b><br>") + "Low: <b>") + fcst.features[0].properties.low) + "<\/b><\/center>";
        } catch ($e) {
          popupText = "Forecast data returned is invalid.";
        };
      };
      var $with1 = new mapboxgl.Popup(null);
      $with1.setLngLat(e.lngLat);
      $with1.setHTML(popupText);
      $with1.addTo($mod.map);
    };
    corslite(((((pas.BoxCast_Config.appSettings.fcstUrl + "?lat1=") + ("" + e.lngLat.lat)) + "&lon1=") + ("" + e.lngLat.lng)) + "&geojson=true", CorsCallback, true);
  };
  this.MapOnMouseEnter = function (e) {
    $mod.map.getCanvas().style.cursor = "pointer";
  };
  this.MapOnMouseLeave = function (e) {
    $mod.map.getCanvas().style.cursor = "";
  };
  this.MapOnLoad = function (e) {
    var scaleOptions = null;
    var aboutButton = null;
    $mod.map.addControl(new mapboxgl.NavigationControl(), "top-left");
    scaleOptions = pas.MapboxGL_Intf.TScaleOptions.$create("Create");
    scaleOptions.maxWidth = 100;
    scaleOptions.unit = "imperial";
    $mod.map.addControl(new mapboxgl.ScaleControl(scaleOptions), "bottom-left");
    aboutButton = $mod.TAboutButtonControl.$create("New");
    $mod.map.addControl(aboutButton, "top-right");
    aboutButton._container.onclick = $mod.AboutOnClick;
    $mod.map.addControl(new mapboxgl.FullscreenControl(), "top-right");
    $mod.map.addLayer(JSON.parse((((((((((((((((((((("{" + '"id": "click-box",') + '"type": "fill",') + '"source": {') + '"type": "geojson",') + '"data": {') + '"type": "Feature",') + '"geometry": {') + '"type": "Polygon",') + '"coordinates": [[[-124.848974, 24.396308],') + "[-124.848974, 49.384358],") + "[ -66.885444, 49.384358],") + "[ -66.885444, 24.396308],") + "[-124.848974, 24.396308]]]") + "}") + "}") + "},") + '"layout": {},') + '"paint": {') + '"fill-opacity": 0') + "}") + "}"), "");
    $mod.map.on("click", "click-box", $mod.MapOnClick);
    $mod.map.on("mouseenter", "click-box", $mod.MapOnMouseEnter);
    $mod.map.on("mouseleave", "click-box", $mod.MapOnMouseLeave);
  };
  this.mapOptions = null;
  $mod.$main = function () {
    mapboxgl.accessToken = pas.BoxCast_Config.appSettings.accessToken;
    $mod.mapOptions = pas.MapboxGL_Intf.TMapOptions.$create("Create");
    $mod.mapOptions.container = "map";
    $mod.mapOptions.style = "mapbox:\/\/styles\/mapbox\/satellite-streets-v10";
    $mod.mapOptions.center = new mapboxgl.LngLat(-107.74, 37.92);
    $mod.mapOptions.zoom = 9.0;
    $mod.mapOptions.logoPosition = "bottom-right";
    $mod.map = new mapboxgl.Map($mod.mapOptions);
    $mod.map.on("load", $mod.MapOnLoad);
  };
});

