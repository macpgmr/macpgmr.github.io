Pascal 'n' JavaScript (PnJ)
Copyright (C) Phil Hess.

Compilable files of source code that are linked into a binary executable or 
library have generally been licensed the same as Free Pascal's RTL, with a 
"modified LGPL" license, as indicated in source comments. See Free Pascal's 
rtl/COPYING.FPC.

The BoxCast files are provided as an example of how to use PnJ.
You can use these files however you want for personal use.

THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.



Notes on PnJ

1. A preliminary report on this initiative is here:
   https://macpgmr.github.io/MacXPlatform/PascalToJavaScript_AReport.html

2. You will need a Free Pascal compiler built from trunk to compile pnj.pas
   (FPC 3.1.1 or later).

3. The included tcmodules.pas and rtl.js files are slightly modified copies of
   FPC trunk files with the same names.

4. To test BoxCast, you will need to substitute your own Mapbox accessToken,
   either in boxcast_config.pas and then generate a new boxcast.js (with the
   supplied convert.sh script or equivalent) or edit the supplied boxcast.js.

5. The supplied System.txt file has a .txt extension so FPC won't attempt
   to compile it when compiling pnj.pas.

6. The only units available are the ones in the supplied interfaces folder.
   No FPC rtl units or packages units are available.
