// This is the mobile app's main class as far as qooxdoo is concerned.
//  Workaround for qooxdoo-Pas2JS chicken-egg problem (ie, have to call
//  Pas2JS's rtl.run to initialize Pascal modules, but can't do that until
//  qooxdoo is loaded and ready to use since modules use qx classes).

// This file must be inserted into the generated Application.js (-JiRunMobileApp.js)
//  since class name in qx.Class.define (eg, myapp.Application) must match
//  directory/file name (eg, myapp/Application.js). Note that class name must
//  be a constant string -- ie, qx.core.Environment.get("qx.application")
//  won't work.

// qooxdoo hints - edit to include additional resource files in build:
/**
 * @asset(myapp/css/*)
*/

qx.Class.define("myapp.Application",
{
  extend : qx.application.Mobile,

  members :
  {
    main : function()  //called by BaseInit.ready()
    {
      this.base(arguments);  //call superclass

      //from standard boilerplate code added by create-application.py:
      // Enable logging in debug variant
      if (qx.core.Environment.get("qx.debug"))
      {
        // support native logging capabilities, e.g. Firebug for Firefox
        qx.log.appender.Native;
        // support additional cross-browser console.
        // Trigger a "longtap" event on the navigation bar for opening it.
        qx.log.appender.Console;
      }

      rtl.run();  //init Pascal modules and run program module's code (app's actual code)

    }
  }
});
