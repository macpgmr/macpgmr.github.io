Pascal 'n' JavaScript (PnJ)
Copyright (C) Phil Hess.

Compilable files of source code that are linked into a binary executable or 
library have generally been licensed the same as Free Pascal's RTL, with a 
"modified LGPL" license, as indicated in source comments. See Free Pascal's 
rtl/COPYING.FPC.

THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.



Notes on PnJ

1. A preliminary report on this initiative is here:
   https://macpgmr.github.io/MacXPlatform/PascalToJavaScript_AReport.html

2. You will need the Free Pascal pas2js transpiler and RTL, available here:
    ftp://ftpmaster.freepascal.org/fpc/contrib/pas2js

3. To test the BoxCast P2J example app, you will need to substitute your own 
   Mapbox accessToken in boxcast_config.pas.
