#!/bin/sh
set -e

pas2jsdir=~/Tools/pas2js/bin
qxunitsdir=~/Tools/pnj/packages/qooxdoo

$pas2jsdir/pas2js -Jirtl.js -JiRunMobileApp.js -Jc -JoUseStrict- -Tbrowser -Fu$qxunitsdir Application.pas
