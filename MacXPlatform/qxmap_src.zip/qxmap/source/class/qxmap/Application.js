/* ************************************************************************

   Copyright:

   License:

   Authors:

************************************************************************ */

/**
 * This is the main application class of your custom application "QxMap"
 *
 * @asset(qxmap/*)
 */
qx.Class.define("qxmap.Application",
{
  extend : qx.application.Mobile,


  members :
  {

    /**
     * This method contains the initial application code and gets called
     * during startup of the application
     */
    main : function()
    {
      // Call super class
      this.base(arguments);

      // Enable logging in debug variant
      if (qx.core.Environment.get("qx.debug"))
      {
        // support native logging capabilities, e.g. Firebug for Firefox
        qx.log.appender.Native;
        // support additional cross-browser console.
        // Trigger a "longtap" event on the navigation bar for opening it.
        qx.log.appender.Console;
      }

      /*
      -------------------------------------------------------------------------
        Below is your actual application code...
        Remove or edit the following code to create your application.
      -------------------------------------------------------------------------
      */


      var manager = new qx.ui.mobile.page.Manager(false);

      var Map = new qxmap.page.Map();
      manager.addDetail(Map);

      var About = new qxmap.page.About();
      manager.addDetail(About);

      Map.addListener("showAbout", function(evt) {
        About.show();
      }, this);

      // Return to the map page
      About.addListener("back", function(evt) {
        Map.show({reverse:true});
      }, this);

      Map.show();
    }
  }
});

