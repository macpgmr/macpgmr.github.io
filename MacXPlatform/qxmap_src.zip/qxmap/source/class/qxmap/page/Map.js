// Mobile page showing an OpenStreetMap map with labeled locations.
//  This version is for OpenLayers 3.

// Adapted from qooxdoo trunk MobileShowcase app's Maps.js page, with
//  added _loadLocations, _loadData, _mergeData and _labelLocations
//  functions.
//  Also eliminated geolocation code and moved various settings out 
//  of code and into config.json.

/**
 * @ignore(ol.*)
 * @asset(qx/mobile/css/*)
*/


qx.Class.define("qxmap.page.Map",
{
  extend : qx.ui.mobile.page.NavigationPage,

  construct : function() {
    this.base(arguments);
    this.set( {
      title : qx.core.Environment.get("appName"),
      showButton : true,
      buttonText : "About"
    });
    qx.bom.Stylesheet.includeFile(qx.core.Environment.get("olCssUrl"));
  },


  events : {
    showAbout : "qx.event.type.Data"
  },


  properties : {
    locations :
    {
      check : "qx.data.Array",
      nullable : true,
      init : null,
      event : "changeLocations"
    }
  },


  members : {

    _map : null,
    _markers : null,
    _data : null,


     // overridden
    _initialize : function() {
      this.base(arguments);

      this._loadMapLibrary();

      qx.event.Registration.addListener(window, "orientationchange", this._redrawMap, this);
      qx.event.Registration.addListener(window, "resize", this._redrawMap, this);

      this.addListener("action", this._onAboutTap, this);
       //Note: "action" is the NavigationPage event that fires when user
       // taps the navigation button (labeled "About") 
    },


    _redrawMap : function() {
      if (this._map !== null) {
        this._map.updateSize();
      }
    },


     // overridden
    _createScrollContainer : function() {
      var mapContainer = new qx.ui.mobile.container.Composite();
      mapContainer.setId("map");
      mapContainer.addCssClass("map");
      return mapContainer;
    },


     // Load the OpenLayers JavaScript mapping library.
    _loadMapLibrary : function() {
      var req = new qx.bom.request.Script();

      req.onload = function() {
        this._initMap();
      }.bind(this);

      req.open("GET", qx.core.Environment.get("olJsUrl"));
      req.send();
    },


     // Initialize the map.
    _initMap : function() {

      var osmlayer = new ol.layer.Tile(
      {
        source : new ol.source.OSM(
        {
          url : qx.core.Environment.get("osmUrl")
        })
      });

      var view = new ol.View(
      {
        zoom    : qx.core.Environment.get("mapZoomLevel"),
        minZoom : 2,
        maxZoom : 19
      });

      this._map = new ol.Map(
      {
        target : "map",
        layers : [osmlayer],
        view   : view
      });

      this._zoomToDefaultPosition();

      this._loadLocations();
    },


     // Load the map locations.
    _loadLocations : function() {
      var queryObj = qx.util.Uri.parseUri(window.location.search, false);
      if (queryObj.queryKey["locations"] != undefined) {  //Locations passed in query?
        var jsonData = queryObj.queryKey["locations"];
        jsonData = decodeURIComponent(jsonData);
        var parser = new qx.util.ResponseParser("json");
        var parsedData = parser.parse(jsonData);
        var modelData = qx.data.marshal.Json.createModel(parsedData);
        this.setLocations(modelData);
        this._loadData();

      } else {  //Load locations from JSON file
        var locationsUrl = qx.core.Environment.get("locsJsonUrl");
        var locationsStore = new qx.data.store.Json(locationsUrl);
        locationsStore.bind("model", this, "locations");

        locationsStore.addListener("error", function(evt) {
          qx.ui.mobile.dialog.Manager.getInstance().alert(
            "Error", "Error loading " + locationsUrl, null, null, "OK");
        }, this);

        locationsStore.addListener("loaded", function(evt) {
          this._loadData();
        }, this);
      }
    },


     // Call server to get data for map locations.
    _loadData : function() {
      if (qx.core.Environment.get("getDataUrl") == "") {  //No server app?
        this._labelLocations();

      } else {
        var req = new qx.bom.request.Jsonp();

        var thisPage = this;  //"this" not accessible w/in onload function
        req.onload = function() {
          thisPage._data = req.responseJson;
          thisPage._mergeData();
        }

        var getDataUrl = qx.core.Environment.get("getDataUrl") + "?";
        for (var locIdx=0, tot=this.getLocations().getLength(); locIdx < tot; locIdx++) {
          if (locIdx > 0)
            getDataUrl = getDataUrl + "&";
          getDataUrl = getDataUrl + 
                       "lat" + (locIdx+1) + "=" + this.getLocations().getItem(locIdx).getLat() + "&" +
                       "lon" + (locIdx+1) + "=" + this.getLocations().getItem(locIdx).getLon();
        }

        req.open("GET", getDataUrl);
        req.send();
      }
    },


     // Merge retrieved data with locations array.
    _mergeData : function() {
      for (var locIdx=0, tot=this._data.length; locIdx < tot; locIdx++) {
        this.getLocations().getItem(locIdx).setDisplay(this._data[locIdx].display);
      }
      this._labelLocations();
    },


     // Label each location on map with its name and data.
    _labelLocations : function() {
       // The map view's default projection is OpenLayers Spherical Mercator
       //  (EPSG:3857, unofficially known as EPSG:900913).

      var fromProjection = ol.proj.get("EPSG:4326");

      for (var locIdx=0, tot=this.getLocations().getLength(); locIdx < tot; locIdx++) {

        var mapPosition = ol.proj.getTransform(fromProjection, this._map.getView().getProjection())
                            ([this.getLocations().getItem(locIdx).getLon(),
                              this.getLocations().getItem(locIdx).getLat()]);
        this._setMarkerOnMap(this._map, mapPosition,
                             this.getLocations().getItem(locIdx).getName() + "\n" +
                             this.getLocations().getItem(locIdx).getDisplay());
      }
    },


    _zoomToDefaultPosition : function() {
      if (this.isVisible()) {
        this._zoomToPosition(qx.core.Environment.get("mapCenterLon"),
                             qx.core.Environment.get("mapCenterLat"),
                             qx.core.Environment.get("mapZoomLevel"),
                             false);
      }
    },


    _zoomToPosition : function(longitude, latitude, zoom, showMarker) {
      var fromProjection = ol.proj.get("EPSG:4326");
      var mapPosition = ol.proj.getTransform(fromProjection, this._map.getView().getProjection())
                          ([longitude, latitude]);

      this._map.getView().setCenter(mapPosition);
      this._map.getView().setZoom(zoom);

      if (showMarker === true) {
        this._setMarkerOnMap(this._map, mapPosition, "");
      }
    },


    _setMarkerOnMap : function(map, mapPosition, markerLabel) {
      if (this._markers == null) {
        this._markers = new ol.layer.Vector(
        {
          source : new ol.source.Vector({})
        });
        map.addLayer(this._markers);
      }

      var point = new ol.Feature(
      {
        geometry : new ol.geom.Point(mapPosition)
      });

      point.setStyle(new ol.style.Style(
      {
        image : new ol.style.Icon(
        {
          src : qx.core.Environment.get("olMarkerUrl")
        }),
        text : new ol.style.Text(
        {
          text      : markerLabel,
          font      : "14px sans-serif",
          textAlign : "left",
          offsetX   : 12
        })
      }));

      this._markers.getSource().addFeature(point);
    },


    _onAboutTap : function(evt) {
      this.fireDataEvent("showAbout", null);
    },


    destruct : function() {
      this._disposeObjects("_map", "_markers", "_data");
    }

  }
});
