// Simple "About" page.

/**
 * @ignore(ol.*)
*/

qx.Class.define("qxmap.page.About",
{
  extend : qx.ui.mobile.page.NavigationPage,

  construct : function() {
    this.base(arguments);
    this.set({
      title : "About",
      showBackButton : true,
      backButtonText : "Back"
    });
  },


  events : {
  },


  properties : {
  },


  members : {

    _initialize : function() {
      this.base(arguments);

      var aboutText =
       "<P style='font-size:22pt; font-weight:bold; text-align:center'>" +
       qx.core.Environment.get("appName") + 
       ", version " + qx.core.Environment.get("appVersion") + "</P><BR>";

      if (qx.core.Environment.get("copyright") != "") {
        aboutText = aboutText + "<P style='font-size:11pt; text-align:center'>" +
                    qx.core.Environment.get("copyright") + "</P><BR>";
      }

      if (qx.core.Environment.get("description") != "") {
        aboutText = aboutText + "<P style='font-size:11pt; text-align:center'>" +
                    qx.core.Environment.get("description") + "</P><BR>";
      }

      aboutText = aboutText +
       "<P style='font-size:11pt; text-align:center'>Browser client running on <A HREF='http://qooxdoo.org' TARGET='_blank'>qooxdoo</A> " +
       qx.core.Environment.get("qx.version") + " and <A HREF='https://openlayers.org' TARGET='_blank'>OpenLayers</A> " + 
       qx.core.Environment.get("olVersion") + ".</P><BR>" +
       "<P style='font-size:11pt; text-align:center'>" + qx.core.Environment.get("osmAttribution") + "</P>";

      // Display all app info in an HTML control
      var label = new qx.ui.mobile.embed.Html();
      label.setHtml(aboutText);
      this.getContent().add(label);

    },  // _initialize

    destruct : function() {
    }

  }
});

