~/Tools/svn_co/lazarus/lazbuild --pcp=~/.lazarus-svn --ws=cocoa --compiler=/usr/local/bin/ppcx64 --cpu=x86_64 pasmap.lpi
