WebBrowserPackage
Copyright (C) Phil Hess.

Compilable files of source code that are linked into a binary executable or 
library have generally been licensed the same as Free Pascal's RTL, with a 
"modified LGPL" license, as indicated in source comments. See Free Pascal's 
rtl/COPYING.FPC.

The PasMap files are provided as an example of how to use the TWebBrowser
control. You can use these files however you want for personal use.

THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.



Notes on WebBrowserPackage

1. TWebBrowser preliminary support is currently implemented only for Cocoa 
   and Qt4 widgetsets.

   Once installed, the TWebBrowser control will appear on the Lazarus
   Common Controls palette.

   You can install the package in Lazarus with any widgetset to use as a 
   placeholder when designing with TWebBrowser. However, with unsupported 
   widgetsets, nothing will  appear in the web browser control's area on the 
   form when an app is run -- this is normal.

2. For notes on compiling with Cocoa from the Lazarus trunk, see the included
   documentation file UsingCocoaFromTrunk.html. You can also view it online:
   https://macpgmr.github.io/MacXPlatform/UsingCocoaFromTrunk.html

3. See the notes at the top of the PasMap example's mainform.pas for more
   information about PasMap.

4. After compiling PasMap on Mac, you can run the fixappbundle.sh script
   to fix up the Lazarus-created .app bundle.

5. By default, macOS blocks calls to insecure HTTP sites. You can relax this 
   restriction by setting the NSAllowsArbitraryLoads key in your app's
   Info.plist file. It should look like this:
     <key>NSAppTransportSecurity</key>
     <dict>
        <key>NSAllowsArbitraryLoads</key>
        <true/>
     </dict>

6. TWebBrowser on Mac can also load .pdf files. Example code:
     WebBrowser1.LoadPage(
      'https://www.freepascal.org/~michael/articles/lazonmac/lazonmac.pdf');

7. Page loading is asynchronous, meaning a call to LoadPage exits immediately
   and loading continues in the background. This can cause problems with
   ShowModal on some platforms. With a TWebBrowser on a modal form, where you 
   want the page to load automatically when the form is displayed, delay the 
   start of page loading by calling LoadPage in the form's OnShow handler
   (rather than in the form's OnCreate handler or before ShowModal is called).

   Example calling code in Form1:
     Form2 := TForm2.Create(Application);
     try
       Form2.ShowModal;
     finally
       Form2.Free;
     end;

   Example OnShow handler in Form2:
     procedure TForm2.FormShow(Sender: TObject);
     begin
       WebBrowser1.LoadPage('https://www.lazarus-ide.org');
     end;

8. Example of using the EvaluateJavaScript method:

     WebBrowser1.EvaluateJavaScript(
      'function DoSum(){var a = 1; var b = 2; var c = a + b; return c;} DoSum();');

   Returns '3'. If evaluation of the JavaScript fails, a blank string will be 
   returned.

9. OnLinkClick event handler: With no handler, browser handles clicked links
   internally if possible. Links that need an external browser 
   (target="_blank") are ignored. With an OnLinkClick handler, clicked links
   are handled as follows (link URL passed to handler): with Cocoa, only _blank 
   links are handled; with Qt, all links are handled.
