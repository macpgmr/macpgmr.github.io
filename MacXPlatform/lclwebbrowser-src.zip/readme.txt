WebBrowserPackage
Copyright (C) Phil Hess.

Compilable files of source code that are linked into a binary executable or 
library have generally been licensed the same as Free Pascal's RTL, with a 
"modified LGPL" license, as indicated in source comments. See Free Pascal's 
rtl/COPYING.FPC.

The PasMap files are provided as an example of how to use the TWebBrowser
control. You can use these files however you want for personal use.

THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.



Notes on WebBrowserPackage

1. TWebBrowser preliminary support is currently implemented only for Cocoa 
   and Qt4 widgetsets.

   You can install the package in Lazarus with any widgetset to use as a 
   placeholder when designing with TWebBrowser, but when run nothing will 
   appear in the web control's area on the form with unsupported widgetsets.

2. For notes on compiling with Cocoa from the Lazarus trunk, see the included
   documentation file UsingCocoaFromTrunk.html. You can also view it online:
   https://macpgmr.github.io/MacXPlatform/UsingCocoaFromTrunk.html

3. See the notes at the top of the PasMap example's mainform.pas for more
   information about PasMap.

4. After compiling PasMap on Mac, you can run the fixappbundle.sh script
   to fix up the Lazarus-created .app bundle.

5. By default, macOS blocks calls to insecure HTTP sites. You can relax this 
   restriction by setting the NSAllowsArbitraryLoads key in your app's
   Info.plist file. It should look like this:
     <key>NSAppTransportSecurity</key>
     <dict>
        <key>NSAllowsArbitraryLoads</key>
        <true/>
     </dict>

