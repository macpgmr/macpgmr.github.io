export PYTHONPATH=/Applications/QGIS.app/Contents/Resources/python
PATH=/System/Library/Frameworks/Python.framework/Versions/2.7/bin
/Applications/QGIS.app/Contents/MacOS/bin/pyuic4 $1.ui >$1.py
