After copying this folder to QGIS's plugins folder, be sure to compile the 
ndfd native library and its module and copy those two files into this folder 
before starting QGIS. See the main Pascal for GIS documentation.

