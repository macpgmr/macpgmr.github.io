/Applications/QGIS.app/Contents/MacOS/bin/pyrcc4 resources.qrc >resources.py
