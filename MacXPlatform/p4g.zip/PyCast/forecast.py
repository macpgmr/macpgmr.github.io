# -*- coding: utf-8 -*-
"""
/***************************************************************************
  PyCast - a plugin for QGIS that gets weather forecast for location.shp's
           points and labels points with high/low temperatures.

  Copyright: (C) 2015 by Phil Hess
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""
from qgis.core import *

def getLocationsLayer(plugin):
    layers = plugin.iface.legendInterface().layers()
    for layer in layers:
        if (layer.type() == QgsMapLayer.VectorLayer) and \
           (layer.originalName() == "Locations"):
            return layer
        # Should layer.source() base filename match "locations.shp"?
    return None


def updateForecast(plugin, ndfd):
    # Make sure project has locations shapefile.
    layer = getLocationsLayer(plugin)
    if layer == None:
        return False, "Project does not have Locations layer."

    # And that it has expected attribute column.
    colIdx = layer.fieldNameIndex("FORECAST")
    if colIdx == -1:
        return False, "Locations layer does not have FORECAST attribute."

    destCrs = QgsCoordinateReferenceSystem()
    destCrs.createFromString("EPSG:4326")  #WGS 84
    transform = QgsCoordinateTransform()
    transform.setSourceCrs(layer.crs())
    transform.setDestCRS(destCrs)

    layer.startEditing()
    for feat in layer.getFeatures():
        point = feat.geometry().asPoint()
        point = transform.transform(point)  #Reproject coords to lat/lon
        if not ndfd.LoadForecast(str(point.y()), str(point.x()), False):
            return False, ndfd.GetLastError()
        feat.setAttribute("FORECAST", "High " + ndfd.GetMaxTemp(1) +
                                      ", Low " + ndfd.GetMinTemp(1))
        layer.updateFeature(feat)
    return True, ""
