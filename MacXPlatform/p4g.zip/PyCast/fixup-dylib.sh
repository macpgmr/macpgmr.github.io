install_name_tool libndfd.dylib -id @loader_path/libndfd.dylib
install_name_tool ndfdmod.so -change ./libndfd.dylib @loader_path/libndfd.dylib
