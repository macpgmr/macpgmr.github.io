# -*- coding: utf-8 -*-
"""
/***************************************************************************
 PyCast
                                 A QGIS plugin
 Labels location.shp's points with high/low temps.
                             -------------------
        begin                : 2014-06-01
        copyright            : (C) 2014 by Phil
        email                : xxx
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
 This script initializes the plugin, making it known to QGIS.
"""

def classFactory(iface):
    # load PyCast class from file PyCast
    from pycast import PyCast
    return PyCast(iface)
