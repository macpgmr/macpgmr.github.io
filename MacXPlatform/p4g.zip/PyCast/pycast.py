# -*- coding: utf-8 -*-
"""
/***************************************************************************
  PyCast - a plugin for QGIS that gets weather forecast for location.shp's
           points and labels points with high/low temperatures.

  Copyright: (C) 2015 by Phil Hess
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""
import os.path

# Import the PyQt and QGIS libraries
from PyQt4.QtCore import *
from PyQt4.QtGui import *
from qgis.core import *  #Doing this triggers QGIS's GPL license

# Initialize Qt resources from file resources.py
import resources

# Import plugin dialogs
from dlg_AboutBox import Dlg_AboutBox

# Import ndfd module's wrapper class.
import NdfdLib

# Import forecast update code
import forecast


class PyCast:

    def __init__(self, iface):
        # Save reference to the QGIS interface
        self.iface = iface

        # Initialize plugin directory
        self.plugin_dir = os.path.dirname(__file__)

        metapath = os.path.join(os.path.dirname(__file__), "metadata.txt" )
        self.metadata = QSettings(metapath, QSettings.IniFormat)
        self.plugin_name = self.metadata.value("name")

        # Initialize locale - Plugin Builder-generated code
        locale = QSettings().value("locale/userLocale")[0:2]
        localePath = os.path.join(self.plugin_dir, "i18n", "pycast_{}.qm".format(locale))
        if os.path.exists(localePath):
            self.translator = QTranslator()
            self.translator.load(localePath)
            if qVersion() > "4.3.3":
                QCoreApplication.installTranslator(self.translator)

        # Connect some interface signals
        iface.projectRead.connect(self.handleProjectRead)
        iface.newProjectCreated.connect(self.handleNewProjectCreated)


    def initGui(self):
        self.ndfd = NdfdLib.NdfdLib()

        self.myMenu = QMenu(self.iface.mainWindow())
        self.myMenu.setTitle(self.plugin_name)

        self.forecastAction = QAction(
            QIcon(":/plugins/" + self.plugin_name + "/Forecast.png"),
            "Update Weather Forecasts", self.iface.mainWindow())
		# Icon courtesy of https://openclipart.org/detail/22012/Weather%20Symbols%3A%20Sun
		#  resized to 23x24 @72 resolution in Gimp.
        self.forecastAction.triggered.connect(self.doForecast)
        self.iface.addToolBarIcon(self.forecastAction)
        self.myMenu.addAction(self.forecastAction)

        self.helpAction = QAction(
            QIcon(":/plugins/" + self.plugin_name + "/Help.png"),
            "Help for " + self.plugin_name, self.iface.mainWindow())
		# Icon courtesy of https://openclipart.org/detail/11322/NPS%20map%20pictographs%20part%202
		#  resized to 23x24 @72 resolution in Gimp.
        self.helpAction.triggered.connect(self.doHelp)
        self.myMenu.addAction(self.helpAction)

        self.aboutAction = QAction(
            QIcon(":/plugins/" + self.plugin_name + "/About.png"),
            "About " + self.plugin_name, self.iface.mainWindow())
		# Icon courtesy of https://openclipart.org/detail/33733/Info%20sign
		#  resized to 23x24 @72 resolution in Gimp.
        self.aboutAction.triggered.connect(self.doAbout)
        self.myMenu.addAction(self.aboutAction)

        self.iface.webMenu().addMenu(self.myMenu)  #assume Web menu already exists


    def unload(self):
        self.iface.webMenu().removeAction(self.myMenu.menuAction())
        self.iface.removeToolBarIcon(self.forecastAction)


    def handleProjectRead(self):
        # Only enable forecast command if reading one of plugin's projects.
        proj = QgsProject.instance()
        enableCmd = proj.readEntry(self.plugin_name, "Version", "")[0] != ""
        self.setMenuCmds(enableCmd)

    def handleNewProjectCreated(self):
        self.setMenuCmds(False)
    
    def setMenuCmds(self, enableCmd):
        self.forecastAction.setEnabled(enableCmd)


    def doForecast(self):
        okay, msg = forecast.updateForecast(self, self.ndfd)
        if not okay:
            QMessageBox.information(None, "Error", msg)
        else:
            self.iface.mapCanvas().refresh()

    def doHelp(self):
        QMessageBox.information(None, "Help", 
          "Open a forecast project (example: " + self.plugin_name + ".qgs), " +
          "then choose " + self.forecastAction.text() + " or click the " +
          self.plugin_name + " button on the toolbar to update the " +
          "forecast for all points in the Locations layer.\n\n" +
          "You can pan and zoom to other parts of the U.S., then add " +
          "your own points to the Locations layer:\n\n" +
          "-Select the Locations layer.\n" + 
          "-Toggle editing on.\n" +
          "-Use the Add Feature tool to add a new point and enter a name " +
          "for the location.\n" +
          "-You can use Open Attribute Table to edit and delete locations.") 

    def doAbout(self):
        aboutBox = Dlg_AboutBox(self.metadata, self.ndfd)
        aboutBox.show()
        aboutBox.exec_()
