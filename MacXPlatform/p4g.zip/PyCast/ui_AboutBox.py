# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui_AboutBox.ui'
#
# Created: Sat Mar  7 20:23:57 2015
#      by: PyQt4 UI code generator 4.11.2
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_AboutBox(object):
    def setupUi(self, AboutBox):
        AboutBox.setObjectName(_fromUtf8("AboutBox"))
        AboutBox.setWindowModality(QtCore.Qt.ApplicationModal)
        AboutBox.resize(400, 300)
        font = QtGui.QFont()
        font.setPointSize(10)
        AboutBox.setFont(font)
        AboutBox.setModal(True)
        self.okBtn = QtGui.QPushButton(AboutBox)
        self.okBtn.setGeometry(QtCore.QRect(310, 260, 75, 23))
        self.okBtn.setDefault(True)
        self.okBtn.setObjectName(_fromUtf8("okBtn"))
        self.infoFrame = QtGui.QFrame(AboutBox)
        self.infoFrame.setGeometry(QtCore.QRect(10, 10, 381, 241))
        self.infoFrame.setFrameShape(QtGui.QFrame.StyledPanel)
        self.infoFrame.setFrameShadow(QtGui.QFrame.Sunken)
        self.infoFrame.setObjectName(_fromUtf8("infoFrame"))
        self.nameLbl = QtGui.QLabel(self.infoFrame)
        self.nameLbl.setGeometry(QtCore.QRect(15, 20, 351, 51))
        font = QtGui.QFont()
        font.setBold(True)
        font.setWeight(75)
        self.nameLbl.setFont(font)
        self.nameLbl.setAlignment(QtCore.Qt.AlignCenter)
        self.nameLbl.setWordWrap(True)
        self.nameLbl.setObjectName(_fromUtf8("nameLbl"))
        self.copyrightLbl = QtGui.QLabel(self.infoFrame)
        self.copyrightLbl.setGeometry(QtCore.QRect(20, 90, 341, 21))
        self.copyrightLbl.setTextFormat(QtCore.Qt.AutoText)
        self.copyrightLbl.setWordWrap(True)
        self.copyrightLbl.setObjectName(_fromUtf8("copyrightLbl"))
        self.pluginVersionLbl = QtGui.QLabel(self.infoFrame)
        self.pluginVersionLbl.setGeometry(QtCore.QRect(20, 130, 341, 21))
        self.pluginVersionLbl.setOpenExternalLinks(True)
        self.pluginVersionLbl.setObjectName(_fromUtf8("pluginVersionLbl"))
        self.libVersionLbl = QtGui.QLabel(self.infoFrame)
        self.libVersionLbl.setGeometry(QtCore.QRect(20, 170, 341, 21))
        self.libVersionLbl.setTextFormat(QtCore.Qt.AutoText)
        self.libVersionLbl.setWordWrap(False)
        self.libVersionLbl.setObjectName(_fromUtf8("libVersionLbl"))

        self.retranslateUi(AboutBox)
        QtCore.QObject.connect(self.okBtn, QtCore.SIGNAL(_fromUtf8("clicked()")), AboutBox.close)
        QtCore.QMetaObject.connectSlotsByName(AboutBox)

    def retranslateUi(self, AboutBox):
        AboutBox.setWindowTitle(_translate("AboutBox", "About PyCast", None))
        self.okBtn.setText(_translate("AboutBox", "OK", None))
        self.nameLbl.setText(_translate("AboutBox", "Name and description go here", None))
        self.copyrightLbl.setText(_translate("AboutBox", "Copyright goes here", None))
        self.pluginVersionLbl.setText(_translate("AboutBox", "Plugin version goes here", None))
        self.libVersionLbl.setText(_translate("AboutBox", "Library version goes here", None))

