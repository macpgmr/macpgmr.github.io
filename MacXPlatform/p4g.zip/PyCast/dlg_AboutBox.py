# -*- coding: utf-8 -*-
"""
/***************************************************************************
  PyCast - a plugin for QGIS that gets weather forecast for location.shp's
           points and labels points with high/low temperatures.

  Copyright: (C) 2015 by Phil Hess
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

import sys
import os.path
from PyQt4 import QtCore
from PyQt4 import QtGui

from ui_AboutBox import Ui_AboutBox


class Dlg_AboutBox(QtGui.QDialog, Ui_AboutBox):
    def __init__(self, metadata, ndfd):
        QtGui.QDialog.__init__(self)

        self.metadata = metadata

        # Set up the user interface from Designer.
        # After setupUI you can access any designer object by doing
        # self.<objectname>, and you can use autoconnect slots - see
        # http://qt-project.org/doc/qt-4.8/designer-using-a-ui-file.html
        # #widgets-and-dialogs-with-auto-connect
        self.setupUi(self)

        name = metadata.value("name")
        description = metadata.value("description")
        author = metadata.value("author")
        version = str(metadata.value("version"))

        self.nameLbl.setText(description)
        self.copyrightLbl.setText(u"Copyright \xa9 2015 " + author)
        self.pluginVersionLbl.setText(name + " plugin version " + version)
        self.libVersionLbl.setText("Ndfd library version " + ndfd.GetLibVersion())
