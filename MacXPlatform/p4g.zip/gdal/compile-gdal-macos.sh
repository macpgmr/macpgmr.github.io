#!/bin/sh
set -e

ppc386=/usr/local/bin/ppc386
ppcx64=/usr/local/bin/ppcx64

if [ "$1" = "" ]; then
  echo Usage: compile-gdal-macos.sh Framework\|Library
  exit 1
fi

if (! [ "$1" = Framework ]) && (! [ "$1" = Library ]); then
  echo "Invalid parameter: $1"
  exit 1
fi

units_root=/Developer/ObjectivePascal/units

i386_units=$units_root/i386-darwin/GDAL/$1
x64_units=$units_root/x86_64-darwin/GDAL/$1

if [ ! -d "$i386_units" ]; then
  mkdir -p "$i386_units"
fi

if [ ! -d "$x64_units" ]; then
  mkdir -p "$x64_units"
fi

if [ "$1" = Framework ]; then
  define=-dGDAL_FRAMEWORK
fi

$ppc386 -Sd -CiroR -gltw $define -FU$i386_units GDAL.pas
$ppcx64 -Sd -CiroR -gltw $define -FU$x64_units GDAL.pas
