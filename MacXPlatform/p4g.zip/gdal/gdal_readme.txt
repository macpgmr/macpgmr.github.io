This package contains the GDAL unit, a Pascal interface for the GDAL library.

You will need the GDAL library to use the GDAL unit.

Note that installing the p4g_ctrls package (which depends on this package) 
will link Lazarus to the GDAL library, meaning you will need the GDAL framework 
installed (OS X) or the GDAL library somewhere on the path in order to start 
Lazarus.

GDAL can be obtained from these sites:

Windows: http://www.gisinternals.com

OS X:    http://www.kyngchaos.com/software/frameworks

Ubuntu:  sudo add-apt-repository ppa:ubuntugis/ubuntugis-unstable
         sudo apt-get update
         sudo apt-get install gdal-bin libgdal-dev

You can also build GDAL yourself. See PascalDynLibs_3.html for more.
