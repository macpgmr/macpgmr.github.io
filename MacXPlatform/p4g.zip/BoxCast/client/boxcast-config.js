// BoxCast's configuration settings.

var appSettings = {
    "name": "BoxCast",
    "version": "0.1",
    "copyright": "Copyright 2017 Phil Hess",
    "fcstUrl": "http://localhost/cgi-bin/getforecast.cgi",
    "accessToken": "your-access-token-goes-here"
      //copy and paste your Mapbox account's Default Public Token
      // or use an access token that you've created at mapbox.com
};
