// BoxCast's configuration settings.

var appSettings = {
    "name": "BoxCast",
    "version": "0.1",
    "copyright": "Copyright 2017 Phil Hess",
    "fcstUrl": "http://localhost/cgi-bin/getforecast.cgi"
};
