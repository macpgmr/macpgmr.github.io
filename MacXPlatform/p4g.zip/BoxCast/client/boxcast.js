// BoxCast's Javascript client code.
// Copyright 2017 Phil Hess.

mapboxgl.accessToken = appSettings.accessToken;

// Create map.
var map = new mapboxgl.Map({
    container: "map",
    style: "mapbox://styles/mapbox/satellite-streets-v10",
    center: [-107.74, 37.92],
    zoom: 9.0,
    logoPosition: "bottom-right" });


 // Set up map.
map.on("load", function () {

     // Add navigation control to map.
    map.addControl(new mapboxgl.NavigationControl(), "top-left");

     // Add scale to map.
    map.addControl(new mapboxgl.ScaleControl({
        maxWidth: 100,
        unit: "imperial" }));

     // Add About button to map.
    var aboutButton = new AboutButtonControl();
    map.addControl(aboutButton);
    aboutButton._container.onclick = function () {
        new mapboxgl.Popup()
            .setLngLat(map.getCenter())
            .setHTML(
                "<center><h3>" + appSettings.name + ", version " + appSettings.version + "</h3>" +
                "<h4>Powered by <a href='https://mapbox.com' target='_blank'>Mapbox GL JS</a>, version " + 
                mapboxgl.version + "<br>" +
                "Weather forecasts from <a href='http://www.usgovxml.com/DataService.aspx?ds=NDFD' " +
                "target='_blank'>National Digital Forecast Database</a></h4>" +
                "Click anywhere in the U.S. to see today's weather forecast.</center>")
            .addTo(map);
    };

     // Add fullscreen control to map.
    map.addControl(new mapboxgl.FullscreenControl());

     // Add layer with bounding box of "lower 48" U.S. states for detecting click.
    map.addLayer({
        "id": "click-box",
        "type": "fill",
        "source": {
            "type": "geojson",
            "data": {
                "type": "Feature",
                "geometry": {
                    "type": "Polygon",
                    "coordinates": [[[-124.848974, 24.396308],
                                     [-124.848974, 49.384358],
                                     [ -66.885444, 49.384358],
                                     [ -66.885444, 24.396308],
                                     [-124.848974, 24.396308]]]
                }
            }
        },
        "layout": {},
        "paint": {
            "fill-opacity": 0
        }
    });

     // Add click handler.
    map.on("click", "click-box", function (e) {
         // Make AJAX call to server (using https://github.com/mapbox/corslite),
         //  passing coordinates of clicked point.
        corslite(appSettings.fcstUrl + "?lat1=" + e.lngLat.lat + "&lon1=" + e.lngLat.lng + "&geojson=true", 
            function(err, resp) {
                if (err) {
                    var popupText = "Error retrieving forecast.";
                    console.log(popupText);
                } else {
                    try {
                        fcst = JSON.parse(resp.response);
                        var popupText = "<center>Today's forecast<br>" + 
                                        "High: <b>" + fcst.features[0].properties.high + "</b><br>" +
                                        "Low: <b>" + fcst.features[0].properties.low + "</b></center>";
                    } catch(e) {
                        var popupText = "Forecast data returned is invalid.";
                    }
                }
                new mapboxgl.Popup()
                    .setLngLat(e.lngLat)
                    .setHTML(popupText)
                    .addTo(map);
            }, true);
    });

     // Change mouse style to pointer when over clickable area.
    map.on("mouseenter", "click-box", function () {
        map.getCanvas().style.cursor = "pointer";
    });

     // Change mouse style back to default when over non-clickable area.
    map.on("mouseleave", "click-box", function () {
        map.getCanvas().style.cursor = "";
    });

});


// Create custom control by implementing Mapbox's IControl interface.
class AboutButtonControl {

    onAdd(map) {
        this._map = map;
        this._container = document.createElement("button");
        this._container.className = "mapboxgl-ctrl";
        this._container.innerHTML = "<b>About</b>";
        return this._container;
    }

    onRemove() {
        this._container.parentNode.removeChild(this._container);
        this._map = undefined;
    }
}
