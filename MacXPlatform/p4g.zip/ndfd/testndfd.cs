// testndfd.cs

using System;
using Ndfd.Interop;

public class TestNdfd
{
  static void Main(string[] args)
  {
    Console.WriteLine("Library version: " + NdfdLib.GetLibVersion());
    NdfdLib Ndfd = new NdfdLib();
    if (!Ndfd.LoadForecast("37.81", "-107.66", false)) {
      Console.WriteLine("Error: " + Ndfd.GetLastError());
    } else {
      for(UInt32 day = 1; day <= 5; day++) {
        Console.WriteLine("Forecast day " + day.ToString() +
                          ": High " + Ndfd.GetMaxTemp(day) +
                          ", Low " + Ndfd.GetMinTemp(day));
      }
    }
  }
}
