//  NdfdLib.cs

//  C# wrapper class for ndfd library.

//  Author:    Phil Hess.
//  Copyright: Copyright (C) Phil Hess.
//  License:   Modified LGPL (see Free Pascal's rtl/COPYING.FPC).

using System;
using System.Text;
using System.Runtime.InteropServices;

namespace Ndfd.Interop
{
  public class NdfdLib: IDisposable
  {
  #if USE_64_BIT
    private const string NdfdLibNameBase = "ndfd64";
  #else
    private const string NdfdLibNameBase = "ndfd";
     //Note 32-bit Mono on OS X needs 32-bit or "fat" libndfd.dylib
  #endif

  #if USE_STDCALL
    private const CallingConvention NdfdCallConv = CallingConvention.StdCall;
  #elif USE_WINAPI  //uses StdCall on Windows and Cdecl on OS X and Linux
    private const CallingConvention NdfdCallConv = CallingConvention.Winapi;
  #else
    private const CallingConvention NdfdCallConv = CallingConvention.Cdecl;
  #endif

  //See ndfd.pas for description of each library function.
     [DllImport(NdfdLibNameBase,
                CharSet=CharSet.Ansi,
                CallingConvention=NdfdCallConv)]
    private static extern void NdfdGetLibVersion(StringBuilder VerBuf,
                                                 UInt32 VerBufLen);

     [DllImport(NdfdLibNameBase,
                CharSet=CharSet.Ansi,
                CallingConvention=NdfdCallConv)]
    private static extern IntPtr NdfdInit();

     [DllImport(NdfdLibNameBase,
                CharSet=CharSet.Ansi,
                CallingConvention=NdfdCallConv)]
    private static extern Int32 NdfdUninit(IntPtr NdfdObj);

     [DllImport(NdfdLibNameBase,
                CharSet=CharSet.Ansi,
                CallingConvention=NdfdCallConv)]
    private static extern void NdfdGetLastError(IntPtr NdfdObj,
                                                StringBuilder ErrBuf,
                                                UInt32 ErrBufLen);

     [DllImport(NdfdLibNameBase,
                CharSet=CharSet.Ansi,
                CallingConvention=NdfdCallConv)]
    private static extern Int32 NdfdLoadForecast(IntPtr NdfdObj,
                                                 String Latitude,
                                                 String Longitude,
                                                 Int32 GetMetric);

     [DllImport(NdfdLibNameBase,
                CharSet=CharSet.Ansi,
                CallingConvention=NdfdCallConv)]
    private static extern Int32 NdfdGetMaxTemp(IntPtr NdfdObj,
                                               UInt32 DayNum,
                                               StringBuilder TempBuf,
                                               UInt32 TempBufLen);

     [DllImport(NdfdLibNameBase,
                CharSet=CharSet.Ansi,
                CallingConvention=NdfdCallConv)]
    private static extern Int32 NdfdGetMinTemp(IntPtr NdfdObj,
                                               UInt32 DayNum,
                                               StringBuilder TempBuf,
                                               UInt32 TempBufLen);


    private IntPtr NdfdObj;

    public NdfdLib()
    {
      NdfdObj = NdfdInit();
    }

    public static String GetLibVersion()
    {
      StringBuilder VersionSb = new StringBuilder(20);
      NdfdGetLibVersion(VersionSb, (UInt32)VersionSb.Capacity);
      return VersionSb.ToString();
    }

    public String GetLastError()
    {
      StringBuilder ErrSb = new StringBuilder(200);
      NdfdGetLastError(NdfdObj, ErrSb, (UInt32)ErrSb.Capacity);
      return ErrSb.ToString();
    }

    public Boolean LoadForecast(String Latitude,
                                String Longitude,
                                Boolean GetMetric)
    {
      return Convert.ToBoolean(NdfdLoadForecast(NdfdObj, Latitude, Longitude, 
                               Convert.ToInt32(GetMetric)));
    }

    public String GetMaxTemp(UInt32 DayNum)
    {
      StringBuilder TempSb = new StringBuilder(20);
      if (NdfdGetMaxTemp(NdfdObj, DayNum, TempSb, (UInt32)TempSb.Capacity) == 0) {
        return "";
      } else {
        return TempSb.ToString();
      }
    }

    public String GetMinTemp(UInt32 DayNum)
    {
      StringBuilder TempSb = new StringBuilder(20);
      if (NdfdGetMinTemp(NdfdObj, DayNum, TempSb, (UInt32)TempSb.Capacity) == 0) {
        return "";
      } else {
        return TempSb.ToString();
      }
    }


// For discussion of the IDisposable interface:
//  https://msdn.microsoft.com/en-us/library/vstudio/system.idisposable%28v=vs.100%29.aspx
    public void Dispose()
    {
      Dispose(true);
      GC.SuppressFinalize(this);
    }

    protected virtual void Dispose(bool disposing)
    {
      if(disposing) {
       //If need to free any managed objects
      }
      NdfdUninit(NdfdObj);  //Make sure library frees "unmanaged" resources
    }

    ~NdfdLib()
    {
      Dispose(false);
    }

  }
}
