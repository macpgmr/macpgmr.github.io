// testndfd.swift

var ndfd = NdfdLib()
print("Library version: \( ndfd.getLibVersion() )") 
if !ndfd.loadForecast(latitude:"37.81", longitude:"-107.66", getMetric:false) {
  print("Error: \( ndfd.getLastError() )")
} else {
  for day:UInt in 1...5 {
    print("Forecast day \( day ): " +
          "High \( ndfd.getMaxTemp(dayNum:day) )" +
          ", Low \( ndfd.getMinTemp(dayNum:day) )")
  }
}
