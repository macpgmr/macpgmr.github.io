~/Tools/svn_co/wst/ws_helper/ws_helper -uA -p -o. -d -gSS -fhttp_graphical_weather_gov_xml_DWMLgen_schema_DWML_xsd=ndfdDWML_schema ndfdXML.wsdl >parsing.txt
# Notes:
#  - Documentation switch (-d) doesn't seem to do anything even though
#     ndfdXML.wsdl has documentation at end of file.
#  - Used -f switch so it doesn't generate superlong unit name.
#  - Doesn't use local DWML.xsd, just local ndfdXML.wsdl.
#  - Used -gSS switch so generated code is not dependent on UnicodeString type.
