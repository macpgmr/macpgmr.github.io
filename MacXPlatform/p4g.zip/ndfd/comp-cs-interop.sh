mcs /target:library /platform:x86 /out:Ndfd.Interop.dll NdfdLib.cs
mcs /target:library /platform:x64 /define:USE_64_BIT /out:Ndfd64.Interop.dll NdfdLib.cs
