ppc386 -dUSE_PYTHON3 -k/Library/Frameworks/Python.framework/Versions/3.5/Python -ondfdmod_3.so ndfdmod.pas
ppcx64 -dUSE_PYTHON3 -k/Library/Frameworks/Python.framework/Versions/3.5/Python -ondfdmod64_3.so ndfdmod.pas
lipo -create ndfdmod_3.so ndfdmod64_3.so -output ndfdmod_3.so
install_name_tool -id ./ndfdmod_3.so ndfdmod_3.so
rm ndfdmod64_3.so
