ppc386 -CiroR -O2 -XX -Fu~/Tools/WST testndfd.pas
