#!/bin/sh
set -e

if [ "$1" = "" ]; then
  echo Usage: create-framework.sh universal\|64bit
  exit 1
fi

if ! [ -e "libndfd.dylib" ]; then
  echo libndfd.dylib does not exist
  exit 1
fi

if [ -e "NDFD.framework" ]; then
  echo NDFD.framework already exists
  exit 1
fi

mkdir NDFD.framework
cd NDFD.framework
mkdir Versions
cd Versions
mkdir A
cd A
mkdir Headers
mkdir Resources
cd ..
ln -s A Current
cd ..
ln -s Versions/Current/Headers Headers
ln -s Versions/Current/Resources Resources
ln -s Versions/Current/NDFD NDFD
cd ..
cp -p ndfd.h NDFD.framework/Versions/A/Headers
cp -p NDFD.framework.Info.plist NDFD.framework/Versions/A/Resources/Info.plist
cp -p libndfd.dylib NDFD.framework/Versions/A/NDFD
if [ "$1" = "64bit" ]; then
  lipo NDFD.framework/Versions/A/NDFD -remove i386 -output NDFD.framework/Versions/A/NDFD
fi
install_name_tool -id @rpath/NDFD.framework/Versions/A/NDFD NDFD.framework/Versions/A/NDFD
