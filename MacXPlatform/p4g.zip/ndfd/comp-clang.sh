clang -L. -lndfd -m32 -otestndfd testndfd.c
clang -L. -lndfd -m64 -otestndfd64 testndfd.c
lipo -create testndfd testndfd64 -output testndfd
rm testndfd64