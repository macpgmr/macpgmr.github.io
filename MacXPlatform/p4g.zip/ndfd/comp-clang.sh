#!/bin/bash
if [ ${OSTYPE:0:6} = "darwin" ]; then
  clang -L. -lndfd -m32 -otestndfd testndfd.c
  clang -L. -lndfd -m64 -otestndfd64 testndfd.c
  lipo -create testndfd testndfd64 -output testndfd
  rm testndfd64
else  #Linux
  clang -L. -lndfd64 -m64 -otestndfd testndfd.c
fi
