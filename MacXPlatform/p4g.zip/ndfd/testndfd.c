// testndfd.c
#include "ndfd.h"
#include <stdio.h>

int main()
{
  NDFD_CHAR StrBuf[200];  //Return strings in this array
  NdfdGetLibVersion(StrBuf, sizeof(StrBuf));
  printf("Library version: %s\n", StrBuf);

  NDFD_POBJ NdfdObj;
  NdfdObj = NdfdInit();

  if (NdfdLoadForecast(NdfdObj, "37.81", "-107.66", 0) == 0) {
    NdfdGetLastError(NdfdObj, StrBuf, sizeof(StrBuf));
    printf("%s\n", StrBuf);
    NdfdUninit(NdfdObj);
    return 1;
  }

  NDFD_UINT DayNum;
  NDFD_CHAR StrBuf2[200];
  for (DayNum = 1; DayNum < 6; DayNum++) {
    NdfdGetMaxTemp(NdfdObj, DayNum, StrBuf, sizeof(StrBuf));
    NdfdGetMinTemp(NdfdObj, DayNum, StrBuf2, sizeof(StrBuf2));
    printf("Forecast day %u: High %s, Low %s\n", DayNum, StrBuf, StrBuf2);
  }

  NdfdUninit(NdfdObj);
}
