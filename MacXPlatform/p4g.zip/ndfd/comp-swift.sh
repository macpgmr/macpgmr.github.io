cp -p testndfd.swift main.swift
swiftc -import-objc-header ndfd.h -L. -lndfd -otestndfd main.swift NdfdLib.swift
rm main.swift
