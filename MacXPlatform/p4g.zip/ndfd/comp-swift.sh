#!/bin/bash
cp -p testndfd.swift main.swift
if [ ${OSTYPE:0:6} = "darwin" ]; then  #OS X, link to universal library
  swiftc -import-objc-header ndfd.h -L. -lndfd -otestndfd main.swift NdfdLib.swift
else  #Linux, link to 64-bit library
  swiftc -import-objc-header ndfd.h -L. -lndfd64 -otestndfd main.swift NdfdLib.swift
fi
rm main.swift
