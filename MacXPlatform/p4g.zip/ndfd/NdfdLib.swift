//  NdfdLib.swift

//  Swift wrapper class for ndfd library.

//  Author:    Phil Hess.
//  Copyright: Copyright (C) Phil Hess.
//  License:   Modified LGPL (see Free Pascal's rtl/COPYING.FPC).

func arrayToString(cStr: [NDFD_CHAR]) -> String {  //CChar
 //Convert null-terminated array of characters to string.
 // If array is empty or bad, return empty string instead of nil.

  if let aStr = String.fromCString(cStr) {  //succeeded?
    return aStr
  }
  else {  //array is empty or contains ill-formed UTF-8
    return ""
  }
}


class NdfdLib {

  private var ndfdObj: NDFD_POBJ  //UInt
  private var strBuf: [NDFD_CHAR]  //CChar = Int8
  private var strBufLen: NDFD_UINT  //UInt32

  init() {
    ndfdObj = NdfdInit()
    strBuf = [NDFD_CHAR](count:200, repeatedValue:0)
    strBufLen = NDFD_UINT(strBuf.count)  //conversion necessary from Int
  }

  deinit {
    NdfdUninit(ndfdObj)
  }

  func getLibVersion() -> String {
    NdfdGetLibVersion(strBuf, strBufLen)
    return arrayToString(strBuf)
  }

  func getLastError() -> String {
    NdfdGetLastError(ndfdObj, strBuf, strBufLen)
    return arrayToString(strBuf)
  }

  func loadForecast(latitude latitude: String,
                    longitude: String,
                    getMetric: Bool) -> Bool {
    if (NdfdLoadForecast(ndfdObj, latitude, longitude, getMetric ? -1 : 0) == 0) { 
      return false
    } else {
      return true
    }
  }

  func getMaxTemp(dayNum dayNum : UInt) -> String {
    if (NdfdGetMaxTemp(ndfdObj, NDFD_UINT(dayNum), strBuf, strBufLen) == 0) {
      return ""
    } else {
      return arrayToString(strBuf)
    }
  }

  func getMinTemp(dayNum dayNum : UInt) -> String {
    if (NdfdGetMinTemp(ndfdObj, NDFD_UINT(dayNum), strBuf, strBufLen) == 0) {
      return ""
    } else {
      return arrayToString(strBuf)
    }
  }
}  //class NdfdLib
