//  NdfdLib.swift

//  Swift wrapper class for ndfd library.

//  Note this version of the wrapper class is for the Swift version 3 compiler
//   available for OS X (Xcode 8) and Ubuntu (swift.org).

//  Author:    Phil Hess.
//  Copyright: Copyright (C) Phil Hess.
//  License:   Modified LGPL (see Free Pascal's rtl/COPYING.FPC).


class NdfdLib {

  private var ndfdObj: NDFD_POBJ  //UInt
  private var strBuf: [NDFD_CHAR]  //CChar = Int8
  private var strBufLen: NDFD_UINT  //UInt32

  init() {
    ndfdObj = NdfdInit()
    strBuf = [NDFD_CHAR](repeating:0, count:200)
    strBufLen = NDFD_UINT(strBuf.count)  //conversion necessary from Int
  }

  deinit {
    NdfdUninit(ndfdObj)
  }

  func getLibVersion() -> String {
    NdfdGetLibVersion(strBuf, strBufLen)
    return String(cString:strBuf)
  }

  func getLastError() -> String {
    NdfdGetLastError(ndfdObj, strBuf, strBufLen)
    return String(cString:strBuf)
  }

  func loadForecast(latitude: String,
                    longitude: String,
                    getMetric: Bool) -> Bool {
    if (NdfdLoadForecast(ndfdObj, latitude, longitude, getMetric ? -1 : 0) == 0) { 
      return false
    } else {
      return true
    }
  }

  func getMaxTemp(dayNum : UInt) -> String {
    if (NdfdGetMaxTemp(ndfdObj, NDFD_UINT(dayNum), strBuf, strBufLen) == 0) {
      return ""
    } else {
      return String(cString:strBuf)
    }
  }

  func getMinTemp(dayNum : UInt) -> String {
    if (NdfdGetMinTemp(ndfdObj, NDFD_UINT(dayNum), strBuf, strBufLen) == 0) {
      return ""
    } else {
      return String(cString:strBuf)
    }
  }
}  //class NdfdLib
