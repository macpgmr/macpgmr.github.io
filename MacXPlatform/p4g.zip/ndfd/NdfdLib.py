# NdfdLib.py
#
# Wrapper class for ndfdmod Python extension module, which calls ndfd library.
#
# Copyright 2015 Phil Hess. All rights reserved.

import array, sys, platform
if sys.version < "3":  #Python 2.x
  if ((sys.platform == "win32") or (sys.platform == "linux2")) and \
     (platform.architecture()[0] == "64bit"):
    import ndfdmod64 as ndfdmod  #64-bit Python, so use 64-bit module and lib
  else:
    import ndfdmod
else:  #Python 3.x
  if ((sys.platform == "win32") or (sys.platform == "linux")) and \
     (platform.architecture()[0] == "64bit"):
    import ndfdmod64_3 as ndfdmod  #64-bit Python, so use 64-bit module and lib
  else:
    import ndfdmod_3 as ndfdmod


class NdfdLib(object):
  #See ndfd.pas for description of each library function called by ndfdmod.

  def __init__(self):
    self.NdfdObj = int(ndfdmod.Init())
    if sys.version < "3":
      self.Buffer = array.array("c", "\0"*20)  #Return data in this
    else:
      self.Buffer = bytes(20)  #Return data in this

  def __del__(self):
    ndfdmod.Uninit(self.NdfdObj)

  def GetLibVersion(self):
    return ndfdmod.GetLibVersion()

  def GetLastError(self):
    return ndfdmod.GetLastError(self.NdfdObj)

  def LoadForecast(self, Latitude, Longitude, GetMetric):
    if ndfdmod.LoadForecast(self.NdfdObj, Latitude, Longitude, GetMetric):
      return True
    else:
      return False

  def GetMaxTemp(self, DayNum):
    if ndfdmod.GetMaxTemp(self.NdfdObj, DayNum, self.Buffer):
      if sys.version < "3":
        ValueStr = self.Buffer.tostring()
      else: 
        ValueStr = self.Buffer.decode()
      return ValueStr[0:ValueStr.find("\0")]
    else:
      return ""

  def GetMinTemp(self, DayNum):
    if ndfdmod.GetMinTemp(self.NdfdObj, DayNum, self.Buffer):
      if sys.version < "3":
        ValueStr = self.Buffer.tostring()
      else: 
        ValueStr = self.Buffer.decode()
      return ValueStr[0:ValueStr.find("\0")]
    else:
      return ""
