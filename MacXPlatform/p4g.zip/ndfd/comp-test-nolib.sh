WST_DIR=~/Tools/WST
ppcx64 -CiroR -O2 -XX -Fu$WST_DIR testndfd.pas
