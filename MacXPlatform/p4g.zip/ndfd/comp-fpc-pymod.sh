#!/bin/bash
if [ ${OSTYPE:0:6} = "darwin" ]; then  #OS X
# This will link against first Python framework that linker finds; may not be
#   what we want if more than one copy of Python 2.7 is installed:
#  ppc386 -k-framework -kPython -ondfdmod.so ndfdmod.pas
#  ppcx64 -k-framework -kPython -ondfdmod64.so ndfdmod.pas
# Explicitly link against system Python's library (run scripts with /usr/bin/python):
  ppc386 -k/System/Library/Frameworks/Python.framework/Versions/2.7/Python -ondfdmod.so ndfdmod.pas
  ppcx64 -k/System/Library/Frameworks/Python.framework/Versions/2.7/Python -ondfdmod64.so ndfdmod.pas
  lipo -create ndfdmod.so ndfdmod64.so -output ndfdmod.so
  rm ndfdmod64.so
  install_name_tool -id ./ndfdmod.so ndfdmod.so
# Uncomment install_name_tool line below to use the Python extension module
#   with system Python 2.7 on El Capitan (10.11) and later. System Integrity 
#   Protection (SIP) restricts programs in protected locations 
#   (eg, /usr/bin/python) from using a library (eg, ndfdmod.so) that references 
#   another library (eg, libndfd.dylib) with a relative reference.
# Change relative reference to library to absolute reference:
#  install_name_tool ndfdmod.so -change ./libndfd.dylib $(pwd)/libndfd.dylib

else  #Linux
  ppcx64 -Cg -ondfdmod64.so ndfdmod.pas
fi
