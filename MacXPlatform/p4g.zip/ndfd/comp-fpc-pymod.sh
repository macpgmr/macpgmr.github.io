ppc386 -k-framework -kPython -ondfdmod.so ndfdmod.pas
ppcx64 -k-framework -kPython -ondfdmod64.so ndfdmod.pas
lipo -create ndfdmod.so ndfdmod64.so -output ndfdmod.so
install_name_tool -id ./ndfdmod.so ndfdmod.so
rm ndfdmod64.so
