#!/bin/bash

# To compile for a specific HTTP client, specify the appropriate define
#  (eg, -dUseNSHttpClient) and path (eg, -Fu~/Tools/nsunits-src) on
#  the command line.
# To compile with the NDFD SOAP service instead of the default REST
#  service, specify -dUseNdfdSoap and change WST_DIR below as needed.

WST_DIR=~/Tools/WST
if [ ${OSTYPE:0:6} = "darwin" ]; then
  ppc386 -S2h -CiroR -O2 -XX -Fu$WST_DIR $1 $2 $3 ndfd.pas
  ppcx64 -S2h -CiroR -O2 -XX -Fu$WST_DIR -olibndfd64.dylib $1 $2 $3 ndfd.pas
  lipo -create libndfd.dylib libndfd64.dylib -output libndfd.dylib
  install_name_tool -id ./libndfd.dylib libndfd.dylib
  rm libndfd64.dylib
else  #Linux
  ppcx64 -CiroR -O2 -XX -Cg -k-fPIC -Fu$WST_DIR -olibndfd64.so $1 $2 $3 ndfd.pas
fi
