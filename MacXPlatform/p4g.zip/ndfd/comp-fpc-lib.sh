#!/bin/bash
WST_DIR=~/Tools/WST
if [ ${OSTYPE:0:6} = "darwin" ]; then
  ppc386 -CiroR -O2 -XX -Fu$WST_DIR ndfd.pas
  ppcx64 -CiroR -O2 -XX -Fu$WST_DIR -olibndfd64.dylib ndfd.pas
  lipo -create libndfd.dylib libndfd64.dylib -output libndfd.dylib
  install_name_tool -id ./libndfd.dylib libndfd.dylib
  rm libndfd64.dylib
else  #Linux
  ppcx64 -CiroR -O2 -XX -Cg -k-fPIC -Fu$WST_DIR -olibndfd64.so ndfd.pas
fi
