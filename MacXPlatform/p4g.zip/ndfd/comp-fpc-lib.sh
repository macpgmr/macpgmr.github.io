ppc386 -CiroR -O2 -XX -Fu~/Tools/WST ndfd.pas
ppcx64 -CiroR -O2 -XX -Fu~/Tools/WST -olibndfd64.dylib ndfd.pas
lipo -create libndfd.dylib libndfd64.dylib -output libndfd.dylib
install_name_tool -id ./libndfd.dylib libndfd.dylib
rm libndfd64.dylib
