# testndfd.py
import sys
if (sys.platform == "cli"):  #IronPython?
  import clr, System
  if (System.IntPtr.Size == 4):  #32-bit?
    clr.AddReference("Ndfd.Interop")
  else:
    clr.AddReference("Ndfd64.Interop")
  import Ndfd.Interop as NdfdLib
else:  #CPython
  import NdfdLib

ndfd = NdfdLib.NdfdLib()
print("Library version: " + ndfd.GetLibVersion())
if not ndfd.LoadForecast("37.81", "-107.66", False):
  print("Error: " + ndfd.GetLastError())
else:
  for day in range(5):
    print("Forecast day " + str(day+1) + ": High " + ndfd.GetMaxTemp(day+1) +
          ", Low " + ndfd.GetMinTemp(day+1))
