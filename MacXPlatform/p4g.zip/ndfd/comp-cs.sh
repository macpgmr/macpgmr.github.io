#!/bin/bash
if [ ${OSTYPE:0:6} = "darwin" ]; then
  mcs /target:exe /platform:x86 /reference:Ndfd.Interop.dll /out:testndfd.exe testndfd.cs
  mcs /target:exe /platform:x64 /reference:Ndfd64.Interop.dll /out:testndfd64.exe testndfd.cs
else  #Linux
  mcs /target:exe /platform:x64 /reference:Ndfd64.Interop.dll /out:testndfd.exe testndfd.cs
fi
