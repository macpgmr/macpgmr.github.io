//  ndfd.h

//  Header file for ndfd library.

//  Author:    Phil Hess.
//  Copyright: Copyright (C) Phil Hess.
//  License:   Modified LGPL (see Free Pascal's rtl/COPYING.FPC).

#include <stdint.h>

#ifdef _MSC_VER
  #define CDECL __cdecl
  #define STDCALL __stdcall
#else
  #define CDECL  /* */
  #define STDCALL __attribute__((stdcall))
#endif

#ifdef USE_STDCALL
  #define NDFD_CALL STDCALL
#else
  #define NDFD_CALL CDECL
#endif
 //Note issue with 32-bit Windows DLL: if __stdcall is used, 
 // MSVC linker looks for stdcall-decorated "C" function names.
 // http://en.wikipedia.org/wiki/Name_mangling
 // https://msdn.microsoft.com/en-us/library/x7kb4e2f.aspx
 // https://msdn.microsoft.com/en-us/library/deaxefa7.aspx

typedef char NDFD_CHAR;
typedef const NDFD_CHAR* NDFD_PCHAR;
typedef uint32_t NDFD_UINT;
typedef const void* NDFD_POBJ;
typedef int32_t NDFD_BOOL;


  //See ndfd.pas for description of each library function.
void NDFD_CALL NdfdGetLibVersion(NDFD_PCHAR VerBuf,
                                 NDFD_UINT VerBufLen);

NDFD_POBJ NDFD_CALL NdfdInit();

NDFD_BOOL NDFD_CALL NdfdUninit(NDFD_POBJ NdfdObj);

void NDFD_CALL NdfdGetLastError(NDFD_POBJ NdfdObj,
                                NDFD_PCHAR ErrBuf,
                                NDFD_UINT ErrBufLen);

NDFD_BOOL NDFD_CALL NdfdLoadForecast(NDFD_POBJ NdfdObj,
                                     NDFD_PCHAR Latitude,
                                     NDFD_PCHAR Longitude,
                                     NDFD_BOOL GetMetric);

NDFD_BOOL NDFD_CALL NdfdGetMaxTemp(NDFD_POBJ NdfdObj,
                                   NDFD_UINT DayNum,
                                   NDFD_PCHAR TempBuf,
                                   NDFD_UINT TempBufLen);

NDFD_BOOL NDFD_CALL NdfdGetMinTemp(NDFD_POBJ NdfdObj,
                                   NDFD_UINT DayNum,
                                   NDFD_PCHAR TempBuf,
                                   NDFD_UINT TempBufLen);
