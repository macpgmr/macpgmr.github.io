//
//  AppDelegate.swift
//  SwiftCast
//
//  Created by Phil on 2/9/15.
//  Copyright (c) 2015 Phil. All rights reserved.
//

import Cocoa
import WebKit

@NSApplicationMain
class AppDelegate: NSObject, NSApplicationDelegate {

    @IBOutlet weak var window: NSWindow!
    @IBOutlet weak var webview: WebView!
    @IBOutlet weak var button: NSButton!
    @IBOutlet weak var label: NSTextField!

    let ndfd = NdfdLib()

    let htmlPath = Bundle.main.resourcePath! + "/viewForecast.bing.6.2.html"

    let mapCenter = (lat: "37.92", lon: "-107.74")

    let locations = [(loc: "Ouray",     lat: "38.02", lon: "-107.67"),
                     (loc: "Silverton", lat: "37.81", lon: "-107.66"),
                     (loc: "Telluride", lat: "37.94", lon: "-107.81")]


    func applicationDidFinishLaunching(_ aNotification: Notification) {
      NotificationCenter.default.addObserver(
       self, selector: #selector(AppDelegate.webviewDoneLoading),
       name: NSNotification.Name.WebViewProgressFinished, object: webview)
    }


    func applicationWillTerminate(_ aNotification: Notification) {
    }


    @IBAction func buttonClick(_ sender: AnyObject) {
      label.stringValue = "Loading forecast..."
      DispatchQueue.global(qos: .background).async {
         //Load forecast in background queue and exit click handler:
        let forecast = self.getForecastUrl()
        DispatchQueue.main.async {
           //When background loading is done, load map (UI requires main queue):
          self.forecastDoneLoading(okay: forecast.okay, urlStr: forecast.urlStr)
        }
      }
    }


    func forecastDoneLoading(okay: Bool, urlStr: String) {
      if okay {
        label.stringValue = "Loading map..."
        updateMap(urlStr)
      } else {
        let alert = NSAlert()
        alert.informativeText = ndfd.getLastError()
        alert.beginSheetModal(for: window, completionHandler: nil)
        label.stringValue = ""
      }
    }


    func webviewDoneLoading() {
      label.stringValue = ""
    }


    func getForecastUrl() -> (okay: Bool, urlStr: String) {
      var urlStr = htmlPath + "?center=" + mapCenter.lat + "," + mapCenter.lon
      for locIdx in 0...locations.count-1 {
        if !ndfd.loadForecast(latitude: locations[locIdx].lat,
                              longitude: locations[locIdx].lon,
                              getMetric: false) {
          return (false, "")
        }
        urlStr = urlStr + "&loc" + String(locIdx+1) + "="
        urlStr = urlStr + locations[locIdx].lat + "," +
                 locations[locIdx].lon + "," +
                 locations[locIdx].loc + "," +
                 "High " + ndfd.getMaxTemp(dayNum: 1) +
                 " Low " + ndfd.getMinTemp(dayNum: 1)
      }
      urlStr = urlStr.addingPercentEncoding(
                withAllowedCharacters: CharacterSet.urlQueryAllowed)!
      return (true, urlStr)
    }


    func updateMap(_ urlStr: String) {
      let url = URL(string: urlStr)
      let req = URLRequest(url: url!)
      webview.mainFrame.load(req)
    }

}
