//
//  AppDelegate.swift
//  SwiftCast
//
//  Created by Phil on 2/9/15.
//  Copyright (c) 2015 Phil. All rights reserved.
//

import Cocoa
import WebKit

@NSApplicationMain
class AppDelegate: NSObject, NSApplicationDelegate {

    @IBOutlet weak var window: NSWindow!
    @IBOutlet weak var webview: WebView!
    @IBOutlet weak var button: NSButton!

    let ndfd = NdfdLib()

    let htmlPath = NSBundle.mainBundle().resourcePath! + "/viewForecast.bing.6.2.html"

    let mapCenter = (lat:"37.92", lon:"-107.74")

    let locations = [(loc:"Ouray",     lat:"38.02", lon:"-107.67"),
                     (loc:"Silverton", lat:"37.81", lon:"-107.66"),
                     (loc:"Telluride", lat:"37.94", lon:"-107.81")]

    var saveButtonTitle = ""

    func applicationDidFinishLaunching(aNotification: NSNotification) {
      NSNotificationCenter.defaultCenter().addObserver(
       self, selector:"webviewDoneLoading",
       name:WebViewProgressFinishedNotification, object:webview)
    }

    func applicationWillTerminate(aNotification: NSNotification) {
    }

    @IBAction func buttonClick(sender: AnyObject) {
      saveButtonTitle = button.title
      button.title = "Loading forecast..."
      button.display()
      let forecast = getForecastUrl()
      if forecast.okay {
        button.title = "Loading map..."
        updateMap(forecast.urlStr)
      } else {
        let alert = NSAlert()
        alert.informativeText = ndfd.getLastError()
        alert.beginSheetModalForWindow(window, completionHandler:nil)
        button.title = saveButtonTitle
      }
    }

    func webviewDoneLoading() {
      button.title = saveButtonTitle
    }

    func getForecastUrl() -> (okay: Bool, urlStr: String) {
      var urlStr = htmlPath + "?center=" + mapCenter.lat + "," + mapCenter.lon
      for locIdx in 0...locations.count-1 {
        if !ndfd.loadForecast(latitude:locations[locIdx].lat,
                              longitude:locations[locIdx].lon,
                              getMetric:false) {
          return (false, "")
        }
        urlStr = urlStr + "&loc" + String(locIdx+1) + "="
        urlStr = urlStr + locations[locIdx].lat + "," +
                 locations[locIdx].lon + "," +
                 locations[locIdx].loc + "," +
                 "High " + ndfd.getMaxTemp(dayNum:1) +
                 " Low " + ndfd.getMinTemp(dayNum:1)
      }
      urlStr = urlStr.stringByAddingPercentEncodingWithAllowedCharacters(
                       NSCharacterSet.URLQueryAllowedCharacterSet())!
      return (true, urlStr)
    }

    func updateMap(urlStr: String) {
      let url = NSURL(string:urlStr)
      let req = NSURLRequest(URL:url!)
      webview.mainFrame.loadRequest(req)
    }

}
