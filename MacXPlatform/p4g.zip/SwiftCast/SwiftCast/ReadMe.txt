Be sure to compile the native libndfd.dylib library before running
this program.

The program icon is courtesy of https://openclipart.org/detail/22012/Weather%20Symbols%3A%20Sun
pasted into SwiftCast.icns in Icon Composer.
