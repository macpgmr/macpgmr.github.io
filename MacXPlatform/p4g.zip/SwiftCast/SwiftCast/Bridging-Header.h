//
//  Bridging-Header.h
//  SwiftCast
//
//  Created by Phil on 2/22/15.
//  Copyright (c) 2015 Phil. All rights reserved.
//

#ifndef SwiftCast_Bridging_Header_h
#define SwiftCast_Bridging_Header_h

  #include "ndfd.h"

#endif
