/**
 * Mobile page showing an OpenStreetMap map with forecast data.
 *
 * Adapted from qooxdoo MobileShowcase app's Maps.js page, with
 *  added _initMap, _loadForecasts and _labelForecasts functions.
 *
 * @ignore(OpenLayers.*)
 * @asset(qx/mobile/css/*)
*/

qx.Class.define("qxcast.page.Map",
{
  extend : qx.ui.mobile.page.NavigationPage,

  construct : function() {
    this.base(arguments);
    this.set({
      title : "QxCast",
      showButton : true,
      buttonText : "About"
    });
  },


  events : {
    showAbout : "qx.event.type.Data"
  },


  properties : {
  },


  members : {

    _mapUri : "http://www.openlayers.org/api/OpenLayers.js",
    _map : null,
    _layer : null,
    _markers : null,

    _mapCenter : {"lat":37.92, "lon":-107.74},

    _locations : [{"loc":"Ouray",     "lat":38.02, "lon":-107.67},
                  {"loc":"Silverton", "lat":37.81, "lon":-107.66},
                  {"loc":"Telluride", "lat":37.94, "lon":-107.81}],

    _forecasts : null,


    _initialize : function() {
      this.base(arguments);

      this._loadMapLibrary();

      // Listens on window orientation change and resize, and triggers redraw of map.
      // Needed for triggering OpenLayers to use a bigger area, and draw more tiles.
      qx.event.Registration.addListener(window, "orientationchange", this._redrawMap, this);
      qx.event.Registration.addListener(window, "resize", this._redrawMap, this);

      this.addListener("action", this._onAboutTap, this);
       //Note: "action" is the NavigationPage event that fires when user
       // taps the navigation button (labeled "About") 

    },  // _initialize


    /**
     * Calls a redraw on layer. Needed after orientationChange event
     *  and drawing markers.
     */
    _redrawMap : function () {
      if (this._layer !== null) {
        this._map.updateSize();
        this._layer.redraw();
      }
    },


    // overridden
    _createScrollContainer : function()
    {
      // MapContainer
      var layout = new qx.ui.mobile.layout.VBox().set({
        alignX : "center",
        alignY : "middle"
      });

      var mapContainer = new qx.ui.mobile.container.Composite(layout);
      mapContainer.setId("osmMap");

      return mapContainer;
    },


    /**
     * Loads the OpenLayers JavaScript mapping library. Needed before we do
     *  anything else.
     */
    _loadMapLibrary : function() {
      var req = new qx.bom.request.Script();

      req.onload = function() {
        this._initMap();
      }.bind(this);

      req.open("GET", this._mapUri);
      req.send();
    },


    _initMap : function() {
      this._map = new OpenLayers.Map("osmMap");

// Neither the OpenStreetMap default "mapnik" (nor Thunderforest "OpenCycleMap")
//  tileset has much detail, but Thunderforest "Outdoors" tileset does. However,
//  Thunderforest will apparently be requiring an API key, so use mapnik.

      this._layer = new OpenLayers.Layer.OSM("mapnik", null, {});

//      this._layer = new OpenLayers.Layer.OSM("OpenCycleMap",
//       ['http://tile.thunderforest.com/cycle/${z}/${x}/${y}.png'], {});

//      this._layer = new OpenLayers.Layer.OSM("Outdoors",
//       ['http://tile.thunderforest.com/outdoors/${z}/${x}/${y}.png'], {});
// Can also specify tileserver subdomains for different look (and faster?):
//       ['http://a.tile.thunderforest.com/cycle/${z}/${x}/${y}.png',
//        'http://b.tile.thunderforest.com/cycle/${z}/${x}/${y}.png',
//        'http://c.tile.thunderforest.com/cycle/${z}/${x}/${y}.png'], {});

      this._map.addLayer(this._layer);

      this._zoomToDefaultPosition();

      this._loadForecasts();
    },


    _loadForecasts : function() {
      var req = new qx.bom.request.Jsonp();

      var thisPage = this;  //"this" not accessible w/in onload function
      req.onload = function() {
        thisPage._forecasts = req.responseJson;
        thisPage._labelForecasts();
      }

      var fcUrl = qx.core.Environment.get("fcurl") + "?";
      for (var locIdx=0, tot=this._locations.length; locIdx < tot; locIdx++) {
        if (locIdx > 0)
          fcUrl = fcUrl + "&";
        fcUrl = fcUrl + "lat" + (locIdx+1) + "=" + this._locations[locIdx].lat + "&" +
                        "lon" + (locIdx+1) + "=" + this._locations[locIdx].lon;
      }

      req.open("GET", fcUrl);
      req.send();
    },


    _labelForecasts : function() {
      var fromProjection = new OpenLayers.Projection("EPSG:4326");  //WGS 84
       // By default, the map's projection is OpenLayers Spherical Mercator
       //  (EPSG:900913), obtained via getProjectionObject below.

      for (var locIdx=0, tot=this._locations.length; locIdx < tot; locIdx++) {
        var mapPosition = new OpenLayers.LonLat(this._locations[locIdx].lon,
                                                this._locations[locIdx].lat).
                               transform(fromProjection,
                                         this._map.getProjectionObject());
        this._setMarkerOnMap(this._map, mapPosition);

        var popup = new OpenLayers.Popup(
                         null, mapPosition, new OpenLayers.Size(1, 1),
                         "<B>" + this._locations[locIdx].loc + "</B><P>" +
                         "High " + this._forecasts[locIdx].high +
                         " Low " + this._forecasts[locIdx].low, 
                         true, null);

        popup.autoSize = true;  //let it determine size needed

        this._map.addPopup(popup);

         //Appparently only responds to one event without a complicated
         // workaround, so just register one based on type of device.
        if (qx.core.Environment.get("device.type") == "mobile") {
          this._markers.markers[locIdx].events.register("touchstart", popup, function () {
            this.toggle();
          });
        } else {
          this._markers.markers[locIdx].events.register("click", popup, function () {
            this.toggle();
          });
        }
      }
    },


    /**
     * Zooms the map to a default position.
     */
    _zoomToDefaultPosition : function() {
      if (this.isVisible()) {
        this._zoomToPosition(this._mapCenter.lon, this._mapCenter.lat, 11, false);
      }
    },


    /**
     * Zooms the map to specified position.
     * @param longitude {Number} the longitude of the position.
     * @param latitude {Number} the latitude of the position.
     * @param zoom {Integer} zoom level.
     * @param showMarker {Boolean} if a marker should be drawn at the position.
     */
    _zoomToPosition : function(longitude, latitude, zoom, showMarker) {
      var fromProjection = new OpenLayers.Projection("EPSG:4326");
      var mapPosition = new OpenLayers.LonLat(longitude, latitude).
                             transform(fromProjection,
                                       this._map.getProjectionObject());


      this._map.setCenter(mapPosition, zoom);

      if (showMarker === true) {
        this._setMarkerOnMap(this._map, mapPosition);
      }
    },


    /**
     * Draws a marker on the map.
     * @param map {Map} the map object.
     * @param mapPosition {Object} the map position.
     */
    _setMarkerOnMap : function(map, mapPosition) {
      if (this._markers === null) {
        this._markers = new OpenLayers.Layer.Markers("Markers");
        map.addLayer(this._markers);
      }

      var marker = new OpenLayers.Marker(mapPosition, icon);
      var size = new OpenLayers.Size(21, 25);
      var offset = new OpenLayers.Pixel(-(size.w / 2), -size.h);
      var icon = new OpenLayers.Icon('http://www.openlayers.org/dev/img/marker.png', size, offset);
      this._markers.addMarker(marker);
    },


    _onAboutTap : function(evt)
    {
      this.fireDataEvent("showAbout", null);
    }

   },


  destruct : function() {
  }
});
