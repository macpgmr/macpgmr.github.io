/**
 * @ignore(OpenLayers.*)
*/

qx.Class.define("qxcast.page.About",
{
  extend : qx.ui.mobile.page.NavigationPage,

  construct : function() {
    this.base(arguments);
    this.set({
      title : "About",
      showBackButton : true,
      backButtonText : "Back"
    });
  },


  events : {
  },


  properties : {
  },


  members : {

    _initialize : function() {
      this.base(arguments);

      // Display all app info in an HTML control
      var label = new qx.ui.mobile.embed.Html();
      label.setHtml(
       "<P style='font-size:22pt; font-weight:bold; text-align:center'>QxCast</P><BR>" +
       "<P style='font-size:11pt; text-align:center'>&#169; 2015 Phil Hess</P><BR>" +
       "<P style='font-size:11pt; text-align:center'>Browser client running on <A HREF='http://qooxdoo.org' TARGET='_blank'>qooxdoo</A> " +
       qx.core.Environment.get("qx.version") + " and <A HREF='http://dev.openlayers.org/docs/files/OpenLayers-js.html' TARGET='_blank'>OpenLayers</A> " + 
       OpenLayers.VERSION_NUMBER + ".</P><BR>" +
       "<P style='font-size:11pt; text-align:center'>Maps and data &#169; <A HREF='http://www.openstreetmap.org/copyright' TARGET='_blank'>OpenStreetMap contributors</A>.</P><BR>" +
       "<P style='font-size:11pt; text-align:center'>Weather forecasts from <A HREF='http://www.usgovxml.com/DataService.aspx?ds=NDFD' TARGET='_blank'>National Digital Forecast Database (NDFD)</A>.</P>"
      );
      this.getContent().add(label);

    }  // _initialize

   },


  destruct : function() {
  }
});

