#!/bin/sh
set -e

resfolder=PasCast.app/Contents/Resources
macfolder=PasCast.app/Contents/MacOS

mv pascast.app PasCast.app
strip pascast
rm $macfolder/pascast
cp -p pascast $macfolder
rm pascast

cp -p Info.plist PasCast.app/Contents
cp -p PasCast.icns $resfolder

cp -p libndfd.dylib $resfolder
install_name_tool $resfolder/libndfd.dylib -id @executable_path/../Resources/libndfd.dylib
install_name_tool $macfolder/pascast -change ./libndfd.dylib @executable_path/../Resources/libndfd.dylib

if ! [ -e $resfolder/photo.jpg ]; then
 if [ -e photo.jpg ]; then
  cp -p photo.* $resfolder
 fi
fi
if ! [ -e $resfolder/topo.jpg ]; then
 if [ -e topo.jpg ]; then
  cp -p topo.* $resfolder
 fi
fi
if ! [ -e $resfolder/soils.shp ]; then
 if [ -e soils.shp ]; then
  cp -p soils.* $resfolder
 fi
fi
if ! [ -e $resfolder/locations.shp ]; then
  cp -p locations.* $resfolder
fi
