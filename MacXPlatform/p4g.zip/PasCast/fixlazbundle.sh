#!/bin/sh
set -e

if ! [ ${OSTYPE:0:6} = "darwin" ]; then
  echo " Skipping post-compile script -- for Mac only"
  exit
fi

macfolder=PasCast.app/Contents/MacOS
resfolder=PasCast.app/Contents/Resources
frmwkfolder=PasCast.app/Contents/Frameworks

mv pascast.app PasCast.app
strip pascast
rm $macfolder/pascast
cp -p pascast $macfolder
rm pascast

cp -p Info.plist PasCast.app/Contents
cp -p PasCast.icns $resfolder

if ! [ -e $frmwkfolder ]; then
  mkdir $frmwkfolder
fi
cp -p libndfd.dylib $frmwkfolder
install_name_tool $frmwkfolder/libndfd.dylib -id @executable_path/../Frameworks/libndfd.dylib
install_name_tool $macfolder/pascast -change ./libndfd.dylib @executable_path/../Frameworks/libndfd.dylib

if ! [ -e $resfolder/photo.jpg ]; then
 if [ -e photo.jpg ]; then
  cp -p photo.* $resfolder
 fi
fi
if ! [ -e $resfolder/topo.jpg ]; then
 if [ -e topo.jpg ]; then
  cp -p topo.* $resfolder
 fi
fi
if ! [ -e $resfolder/soils.shp ]; then
 if [ -e soils.shp ]; then
  cp -p soils.* $resfolder
 fi
fi
if ! [ -e $resfolder/locations.shp ]; then
  cp -p locations.* $resfolder
fi

# If nothing more will be copied to .app bundle, can codesign here:
#codesign --force --deep --verbose --sign "your signing identity here" PasCast.app
