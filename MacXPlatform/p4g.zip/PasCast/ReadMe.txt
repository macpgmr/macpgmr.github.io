Before you compile this program, make sure you first do the following:

- Download the layer files (image and vector) for PasCast and unzip them
  in the PasCast folder (where this file is):

    https://macpgmr.github.io/MacXPlatform/PasCast_Layers.zip

- Compile the ndfd native library and copy it (.dylib, .dll or .so) to the 
  PasCast folder.

- Compile the ndfd_pkg.lpk runtime package. You can compile it from the 
  command line like this:  lazbuild ndfd_pkg.lpk

- Install the GDAL framework (OS X) or install the GDAL and PROJ libraries
  (Windows and Linux).

- Compile the gdal_pkg.lpk runtime package. You can compile it from the
  command line like this:  lazbuild gdal_pkg.lpk

- In Lazarus, compile and install the p4g_ctrls.lpk design/runtime package.
  Note that this will link Lazarus to GDAL, meaning you will need the GDAL 
  framework installed (OS X) or the GDAL library somewhere on the path in order
  to start Lazarus.


The program icon is courtesy of https://openclipart.org/detail/22012/Weather%20Symbols%3A%20Sun
pasted into PasCast.icns in Icon Composer.
