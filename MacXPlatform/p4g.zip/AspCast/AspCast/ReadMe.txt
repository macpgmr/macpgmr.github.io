
Before running this program: Be sure you've compiled the native ndfd library
and its interop assembly, then copied those two files along with the DotSpatial 
assemblies into the AspCast folder as described in the main Pascal for GIS 
documentation.
