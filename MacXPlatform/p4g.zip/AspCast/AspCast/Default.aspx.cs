﻿// AspCast's code-behind class for Default.aspx page.
// Copyright 2015 Phil Hess.

using System;
using System.Data;
using System.IO;
using System.Drawing;
using System.Web;
using System.Web.UI;
using System.Reflection;

using DotSpatial.Projections;
using DotSpatial.Data;
using DotSpatial.Symbology;
using DotSpatial.Controls;
using DotSpatial.WebControls;
using DotSpatial.MapWebClient;

using Ndfd.Interop;

namespace AspCast {
	
	public partial class MainPage : System.Web.UI.Page, ICallbackEventHandler {

		private NdfdLib Ndfd;

		public MainPage() {
			Ndfd = new NdfdLib();
		}

		protected void Page_Load(object sender, EventArgs e) {
			if (!IsPostBack) {

				CreateMap ();

				ToolBar.WebMapID = "Map";

				AddToolbarButtons ();

				Legend.WebMapID = "Map";
			}

			// Need to register script with _every_ page load.
			if (!ClientScript.IsClientScriptBlockRegistered("CustomCallServer")) {
				// for now just use DotSpatial's ReceiveServerData JS function
				string cbRef = ClientScript.GetCallbackEventReference(
								this, "arg", "ReceiveServerData", "''", true);
				cbRef = cbRef.Replace("'" + ClientID + "'", "ID");
				string cbScript = "function CustomCallServer(ID,arg) {" + cbRef + "; }";
				ClientScript.RegisterClientScriptBlock(
					this.GetType(), "CustomCallServer", cbScript, true);
			}

			// Override default handlers like this:
			Map.ClickAndPopup += GetForecast;
			Map.AddFeature += AddLocation;
		}


		private void CreateMap() {
			string BasePath = Server.MapPath("Layers") + Path.DirectorySeparatorChar;

			double[] xy = new double[4];
			xy[0] = -107.65;  //minx
			xy[1] = 37.75;  //miny
			xy[2] = -107.85;  //maxx
			xy[3] = 38.05;  //maxy
			double[] z = new double[2];
			z[0] = 1;
			z[1] = 1;
			// Reproject map's extent from lat/lon to map's projection (pseudo-Mercator).
			Reproject.ReprojectPoints(xy, z, KnownCoordinateSystems.Geographic.World.WGS1984,
				                      KnownCoordinateSystems.Projected.World.WebMercator, 0, 2);

			Map.Projection = KnownCoordinateSystems.Projected.World.WebMercator;
			Map.MapViewExtents = new Extent(xy[0], xy[1], xy[2], xy[3]);

			WebMapClient client = new WebMapClient();

			WMTClient WMT1 = new WMTClient();
			WMT1.Create(WebServiceType.BingHybrid);  //use Bing Maps for background
			client.AddService(WMT1);

/*
			// GoogleHybrid previously worked, but image tiles now just show "?".
			WMTClient WMT2 = new WMTClient();
			WMT2.Create(WebServiceType.GoogleHybrid);
			client.AddService(WMT2);
*/

			Map.Back = client;

			// Add shapefile of points to display over background map.
			IMapFeatureLayer LocsLayer = (IMapFeatureLayer)Map.AddLayer(BasePath + "locations.shp");
			LocsLayer.LegendText = "Startup Locations";
			LocsLayer.Symbolizer = new PointSymbolizer(Color.Blue, DotSpatial.Symbology.PointShape.Star, 15);
			LocsLayer.Symbolizer.IsVisible = true;

/*
			// Labeling of shapes currently not working on OS X (works on Windows).
			MapLabelLayer LabelLocs = new MapLabelLayer();
			LabelLocs.Symbology.Categories[0].Expression = "[LOCATION]";
			LabelLocs.Symbolizer.Orientation = ContentAlignment.MiddleRight;
			LabelLocs.Symbolizer.FontSize = 9F;
			LabelLocs.Symbolizer.FontColor = Color.Blue;
			LocsLayer.LabelLayer = LabelLocs;
			LocsLayer.ShowLabels = true;
*/
		}


		private void AddToolbarButtons() {
			ToolBar.CreateStandardButtons ();
			// Several of the standard toolbar buttons are not relevant
			//  to this simple app, but leave in for now (Select feature,
			//  Feature data, Add feature). Desired standard buttons
			//  can be added separately with AddButton.

			// Add custom buttons specific to this app.
			ToolBar.AddButton (WebButtonType.Space);  //set off from standard buttons
			ToolBar.AddButton (WebButtonType.Space);
			ToolBar.AddButton (WebButtonType.Space);
			ToolBar.AddButton (WebButtonType.Space);
			ToolBar.AddButton (WebButtonType.Custom,
				"WebToolBarClickTool('<WebMapID>',ToolClickAndPopup,'<index>');",
				"Images/Forecast.png", "", "Get forecast");
			// Icon courtesy of https://openclipart.org/detail/22012/Weather%20Symbols%3A%20Sun
			//  resized to 24x24 @96 resolution in Gimp.

			ToolBar.AddButton (WebButtonType.Space);
			ToolBar.AddButton (WebButtonType.Custom,
				"CustomCallServer('" + ClientID + "', 'About');",
				"Images/About.png", "", "About");
			// Icon courtesy of https://openclipart.org/detail/33733/Info%20sign
			//  resized to 24x24 @96 resolution in Gimp.

			ToolBar.AddButton (WebButtonType.Space);
			ToolBar.AddButton (WebButtonType.Custom,
				"CustomCallServer('" + ClientID + "', 'Help');",
				"Images/Help.png", "", "Help");
			// Icon courtesy of https://openclipart.org/detail/11322/NPS%20map%20pictographs%20part%202
			//  resized to 24x24 @96 resolution in Gimp.
		}


		private string returnCommand = "";
		private string returnValue = "";

		public string GetCallbackResult() {
			string sr = String.Format("{0}|{1}|{2}", ClientID, returnCommand, returnValue);
			return sr;
		}

		public void RaiseCallbackEvent(string eventArgument) {
			string[] arg = eventArgument.Split ('|');
			string cmd = arg [0].ToUpper ();

			switch (cmd) {
				case "ABOUT": {  //return About box information as HTML
					string NdfdVers;
					try {
						NdfdVers = NdfdLib.GetLibVersion();
					}
					catch {
						NdfdVers = "Not available";
					}

					returnCommand = "POPUP";
					returnValue = 
						@"<div style='text-align:center;'>About AspCast</div><hr>" + 
						"<p>" +
						"AspCast version: " + Assembly.GetExecutingAssembly().GetName().Version + "<br>" +
						(Attribute.GetCustomAttribute(
							Assembly.GetExecutingAssembly(), typeof(AssemblyCopyrightAttribute)) 
							as AssemblyCopyrightAttribute).Copyright + "<p>" +
						"DotSpatial version: " + typeof(FeatureSet).Assembly.GetName().Version + "<br>" +
						"Ndfd library version: " + NdfdVers + "<p><hr>";
				}
				break;

				case "HELP": {  //return brief help as HTML
					returnCommand = "POPUP";
					returnValue =
						@"<div style='text-align:center;'>How to use AspCast</div><hr>" +
						"<p>" +
						"Click the 'Get forecast' button (sun), then click anywhere on the map<br>" +
						"to see the forecast for that point.<p>" +
						"Use the zoom and pan buttons to go to any place in the U.S.";
				}
				break;
			}
		}


		private string GetForecast (object Sender, MapClickEventArgs e)
		{
			double[] xy = new double[2];
			xy[0] = e.X;
			xy[1] = e.Y;
			double[] z = new double[1];
			z[0] = 1;
			// Convert clicked point's coords from map's projection to lat/lon.
			Reproject.ReprojectPoints(xy, z, KnownCoordinateSystems.Projected.World.WebMercator,
				                       KnownCoordinateSystems.Geographic.World.WGS1984, 0, 1);

			if (!Ndfd.LoadForecast (xy[1].ToString(), xy[0].ToString(), false)) {
				return "Error: " + Ndfd.GetLastError();
			} else {  //return forecast as HTML
				return "Today's forecast<p>" +
					    "High: " + Ndfd.GetMaxTemp(1) + ", Low: " + Ndfd.GetMinTemp(1);
			}
		}


		// Point shape is added to shapefile with code below, but not displayed on map.
		//  This previously worked with DotSpatial.
		private void AddLocation(Object Sender, FeatureSet fs, Feature f) {
			//Just ignore click.
/*
			if (fs.Name == "locations") {
				try {
					fs.Features.Add(f);
					f.DataRow.BeginEdit();
					f.DataRow["LOCATION"] = "";
					f.DataRow["FORECAST"] = "";
					f.DataRow.EndEdit();
					fs.Save();
				}
				catch {
					fs.Features.Remove(f);
					throw;  //re-throw exception
				}
				fs.InitializeVertices();
				return;
			}
*/
		}

	}
}
