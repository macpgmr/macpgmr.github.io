#!/bin/bash

tfdir=~/Tools/tensorflow-libs/lib
#tfdir=~/Tools/swift/usr/lib/swift/linux

if [ ${OSTYPE:0:6} = "darwin" ]; then  #macOS
  export DYLD_LIBRARY_PATH=$DYLD_LIBRARY_PATH:$tfdir
else  #Linux
  export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$tfdir
fi

./$1
