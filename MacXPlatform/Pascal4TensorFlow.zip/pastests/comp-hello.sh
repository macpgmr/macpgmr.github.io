#!/bin/bash

tfdir=~/Tools/tensorflow-libs/lib
#tfdir=~/Tools/swift/usr/lib/swift/linux

ppcx64 -Sd -Ciro -XX -Fu../ -Fl$tfdir hello_tf.pas

