Pascal for TensorFlow

- TensorFlow C header files and library binaries are here:
    https://www.tensorflow.org/install/install_c

- TensorFlow library binaries are also included with Swift for TensorFlow:
    https://github.com/tensorflow/swift/blob/master/Installation.md

- See the example programs in pastests and the comments at the top of the files.
  The hello_tf.pas example is the simplest, MNIST.pas the most complex.

- The example programs have been tested on these systems:
    macOS 10.11 El Capitan
    macOS 10.13 High Sierra
    Ubuntu 14.04

- If you installed TensorFlow libraries somewhere other than /usr/local/lib,
  edit and use the scripts supplied with the example programs as needed
  to compile and run the programs.
