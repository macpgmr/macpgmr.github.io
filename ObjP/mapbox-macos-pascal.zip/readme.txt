Mapbox macOS SDK for Objective Pascal

- See the comments at the top of Mapbox.pas for useful links.


- Download the mapbox-macos-sdk-0.6.1.zip from here:

    https://github.com/mapbox/mapbox-gl-native/releases/tag/macos-v0.6.1

  Double-click to unzip, then move the mapbox-macos-sdk-0.6.1 folder 
  anywhere you like.

- Download macOS framework interface units (AppKit, etc.) in 
  MacOS_10_10-master.zip:

    https://github.com/genericptr

  Double-click to unzip, then move the MacOS_10_10-master folder anywhere 
  you like.

- Download extras for compiling macOS interface units:

    https://macpgmr.github.io/ObjP/MacOS_10_10-extras.zip

  Double-click to unzip, then copy the files in the MacOS_10_10-extras folder 
  to the MacOS_10_10-master folder.


- To compile Mapbox.pas for use with Xcode:

   - Run compile-appkit.sh script in MacOS_10_10-master folder.

     The compiled macOS interface units will now be in:

       /Developer/ObjectivePascal/units/x86_64-darwin/macOS/NoCocoaAll

   - Run compile-mapbox.sh script in mapbox-macos-pascal folder.

     The compiled Mapbox unit will now be in:

       /Developer/ObjectivePascal/units/x86_64-darwin/Mapbox/NoCocoaAll


- To compile Mapbox.pas for use with Lazarus:

   - Compile macos_common_frameworks.lpk in MacOS_10_10-master folder
     with Lazarus or lazbuild.

   - Compile mapbox_framework.lpk in mapbox-macos-pascal folder with
     Lazarus or lazbuild.
