#!/bin/sh
set -e

fpc_compiler=/usr/local/bin/ppcx64

units_root_dir=/Developer/ObjectivePascal/units/x86_64-darwin
in_units_dir=$units_root_dir/macOS/NoCocoaAll
out_units_dir=$units_root_dir/Mapbox/NoCocoaAll

if [ ! -e "$fpc_compiler" ]; then
  echo "  Can't find $fpc_compiler"
  exit 1
fi

if [ ! -d "$in_units_dir" ]; then
  echo "  Can't find $in_units_dir"
  exit 1
fi

if [ ! -d "$out_units_dir" ]; then
  mkdir -p "$out_units_dir"
fi

$fpc_compiler -Sd -Ciro -Fu"$in_units_dir" -FU"$out_units_dir" Mapbox.pas
