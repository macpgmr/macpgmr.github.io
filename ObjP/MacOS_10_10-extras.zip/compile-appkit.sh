#!/bin/sh
set -e

fpc_x64_compiler=/usr/local/bin/ppcx64
fpc_386_compiler=/usr/local/bin/ppc386

x64_units_dir=/Developer/ObjectivePascal/units/x86_64-darwin/macOS/NoCocoaAll
i386_units_dir=/Developer/ObjectivePascal/units/i386-darwin/macOS/NoCocoaAll

if [ ! -e "$fpc_x64_compiler" ]; then
  echo "  Can't find $fpc_x64_compiler"
  exit 1
fi

if [ ! -e "$fpc_386_compiler" ]; then
  echo "  Can't find $fpc_386_compiler"
  exit 1
fi

if [ ! -d "$x64_units_dir" ]; then
  mkdir -p "$x64_units_dir"
fi

if [ ! -d "$i386_units_dir" ]; then
  mkdir -p "$i386_units_dir"
fi

$fpc_x64_compiler -Sd -Ciro -FU"$x64_units_dir" macos_common_frameworks_xcode.pas
$fpc_386_compiler -Sd -Ciro -FU"$i386_units_dir" macos_common_frameworks_xcode.pas
