Extras for Mac OS X 10.10 interface units

MacOS_10_10-master.zip with source files is available here:

  https://github.com/genericptr

To compile for use with Xcode, run the supplied script:

  ./compile-appkit.sh

To compile for use with Lazarus, compile macos_common_frameworks.lpk
with Lazarus or lazbuild.
