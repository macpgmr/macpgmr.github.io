#!/bin/sh
set -e

ppc386=/usr/local/bin/ppc386
ppcx64=/usr/local/bin/ppcx64
ppcarm=/usr/local/bin/ppcarm

devbindir=/Applications/Xcode.app/Contents/Developer/Platforms/iPhoneOS.Platform/Developer/usr/bin

i386darwin=/Developer/ObjectivePascal/units/i386-darwin
x86_64darwin=/Developer/ObjectivePascal/units/x86_64-darwin
i386iphonesim=/Developer/ObjectivePascal/units/i386-iphonesim
armdarwin=/Developer/ObjectivePascal/units/arm-darwin

if [ ! -d "$i386darwin" ]; then
  echo "Can't find $i386darwin"
  exit 1
fi
if [ ! -d "$x86_64darwin" ]; then
  echo "Can't find $x86_64darwin"
  exit 1
fi
if [ ! -d "$i386iphonesim" ]; then
  echo "Can't find $i386iphonesim"
  exit 1
fi
if [ ! -d "$armdarwin" ]; then
  echo "Can't find $armdarwin"
  exit 1
fi

switches="-CirotR -gltw -Mdelphi"

$ppc386 $switches -FU$i386darwin NSHelpers.pas
$ppc386 $switches -FU$i386darwin NSFormat.pas
$ppc386 $switches -FU$i386darwin ns_url_request.pas
$ppc386 $switches -FU$i386darwin NSMisc.pas
$ppc386 $switches -FU$i386darwin CocoaHelpers.pas

$ppcx64 $switches -FU$x86_64darwin NSHelpers.pas
$ppcx64 $switches -FU$x86_64darwin NSFormat.pas
$ppcx64 $switches -FU$x86_64darwin ns_url_request.pas
$ppcx64 $switches -FU$x86_64darwin NSMisc.pas
$ppcx64 $switches -FU$x86_64darwin CocoaHelpers.pas

$ppc386 -Tiphonesim $switches -FU$i386iphonesim NSHelpers.pas
$ppc386 -Tiphonesim $switches -FU$i386iphonesim NSFormat.pas
$ppc386 -Tiphonesim $switches -FU$i386iphonesim ns_url_request.pas
$ppc386 -Tiphonesim $switches -FU$i386iphonesim NSMisc.pas

$ppcarm -Cparmv7 -Cfvfpv3 -FU/tmp $switches -Fu$armdarwin -FD$devbindir NSHelpers.pas
$ppcarm -Cparmv6 -Cfvfpv2 $switches -Fu$armdarwin -FD$devbindir NSHelpers.pas
/usr/bin/lipo /tmp/NSHelpers.o NSHelpers.o -create -output NSHelpers.o
rm /tmp/NSHelpers.o
rm /tmp/NSHelpers.ppu

$ppcarm -Cparmv7 -Cfvfpv3 -FU/tmp $switches -Fu$armdarwin -FD$devbindir NSFormat.pas
$ppcarm -Cparmv6 -Cfvfpv2 $switches -Fu$armdarwin -FD$devbindir NSFormat.pas
/usr/bin/lipo /tmp/NSFormat.o NSFormat.o -create -output NSFormat.o
rm /tmp/NSFormat.o
rm /tmp/NSFormat.ppu

$ppcarm -Cparmv7 -Cfvfpv3 -FU/tmp $switches -Fu$armdarwin -FD$devbindir ns_url_request.pas
$ppcarm -Cparmv6 -Cfvfpv2 $switches -Fu$armdarwin -FD$devbindir ns_url_request.pas
/usr/bin/lipo /tmp/ns_url_request.o ns_url_request.o -create -output ns_url_request.o
rm /tmp/ns_url_request.o
rm /tmp/ns_url_request.ppu

$ppcarm -Cparmv7 -Cfvfpv3 -FU/tmp $switches -Fu$armdarwin -FD$devbindir NSMisc.pas
$ppcarm -Cparmv6 -Cfvfpv2 $switches -Fu$armdarwin -FD$devbindir NSMisc.pas
/usr/bin/lipo /tmp/NSMisc.o NSMisc.o -create -output NSMisc.o
rm /tmp/NSMisc.o
rm /tmp/NSMisc.ppu

mv NSHelpers.o $armdarwin
mv NSHelpers.ppu $armdarwin
mv NSFormat.o $armdarwin
mv NSFormat.ppu $armdarwin
mv ns_url_request.o $armdarwin
mv ns_url_request.ppu $armdarwin
mv NSMisc.o $armdarwin
mv NSMisc.ppu $armdarwin
