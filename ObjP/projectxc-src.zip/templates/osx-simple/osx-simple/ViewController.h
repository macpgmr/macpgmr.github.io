//
//  ViewController.h
//

#import <Cocoa/Cocoa.h>

@interface ViewController : NSViewController
  // Drag a control's New Referencing Outlet here to add an IBOutlet,
  //  then declare the control in your corresponding Pascal class using
  //  the same name and type.
  // Example Pascal declaration:
  //   button : NSButton;


  // Drag a control's Sent Action here to add an IBAction, then add
  //  the method to your corresponding Pascal class.
  // Example Pascal declaration:
  //   procedure buttonClick(sender: id); message 'buttonClick:';
  //
  // Example Pascal implementation:
  //   procedure ViewController.buttonClick(sender: id);
  //   begin
  //     button.setTitle(NSSTR('Click Me'));
  //   end;


@end
