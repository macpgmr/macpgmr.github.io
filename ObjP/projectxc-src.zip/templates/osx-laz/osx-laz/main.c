
//  Ignore this file. It's just here so Xcode has something it understands
//   and creates a complete .app bundle so we don't have to.

#include <stdio.h>

int main(int argc, const char * argv[]) {
    // insert code here...
    printf("Hello, World!\n");
    return 0;
}
