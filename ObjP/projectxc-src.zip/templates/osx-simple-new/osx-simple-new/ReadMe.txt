
To see the Pascal-specific project settings:

- Click on your project at the top of navigator list. On the Build Phases tab 
of your project's target, expand the Run Script phase to see the script that 
compiles your Pascal source.

- The script draws on several user-defined project settings. To see these, 
scroll to the bottom of the Build Settings tab. To edit one of these settings, 
double-click its value. Note that there are separate settings for both the 
Debug and the Release build configurations.

This project assumes that you are using the individual framework units instead
of FPC's CocoaAll unit. These framework units are available from here:
  https://github.com/genericptr

Be sure to update the path to your framework units in the FPC_X64_UNITS build
setting before building your app.

To build and run your app, choose Product | Run.
